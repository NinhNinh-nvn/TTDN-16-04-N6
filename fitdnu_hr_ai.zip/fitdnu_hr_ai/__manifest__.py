# -*- coding: utf-8 -*-
{
    'name': 'FITDNU HR AI - Minimalist Design',
    'version': '5.1.0',
    'category': 'Human Resources',
    'summary': 'Hệ thống Quản lý Nhân sự - Giao diện Tối giản Chuyên nghiệp',
    'description': """
Hệ thống Quản lý Nhân sự v5.1 - MINIMALIST DESIGN

### ✨ v5.1: THIẾT KẾ TỐI GIẢN CHUYÊN NGHIỆP

**🎨 Giao diện Tối giản:**
- Thiết kế clean, simple, professional
- Màu sắc tối giản, tập trung vào nội dung
- Tables đơn giản với borders mỏng
- Forms rõ ràng, dễ sử dụng
- Buttons theo chuẩn Odoo

**👥 Quản lý Nhân viên:**
- Interface sạch sẽ, dễ đọc
- Tables với header background nhạt
- Hover effects tinh tế
- Status badges đơn giản

**📊 Dashboard Thông minh:**
- KPI cards đơn giản
- Thống kê rõ ràng
- Charts dễ hiểu

**⏰ Chấm công Tự động:**
- Ghi nhận chính xác
- Báo cáo chi tiết
- Interface đơn giản

**💰 Tính lương Tự động:**
- Tính toán chính xác
- Export reports
- Hiển thị rõ ràng

**🔒 Bảo mật:**
- Phân quyền chi tiết
- Audit trail
- Data protection
    """,
    'author': 'FITDNU - Đại học Đại Nam',
    'website': 'https://dainam.edu.vn',
    'license': 'LGPL-3',
    'depends': [
        'base',
        'mail',
        'web',
    ],
    'data': [
        'security/ir.model.access.csv',
        'data/ir_cron_attendance.xml',
        
        # Consolidated Actions (must load first to avoid duplicates)
        'views/actions.xml',
        
        # Dark Minimal Views (Priority)
        'views/dark_minimal_views.xml',
        
        # Views cũ (giữ lại để tương thích)
        'views/employee_views.xml',
        'views/employee_views_minimal.xml',
        'views/attendance_views.xml',
        'views/attendance_views_minimal.xml',
        'views/salary_views.xml',
        'views/salary_views_minimal.xml',
        'views/hr_contract_views.xml',
        'views/hr_work_history_views.xml',
        'views/hr_training_history_views.xml',
        'views/hr_reward_discipline_views.xml',
        'views/hr_payroll_views.xml',
        'views/hr_department_views.xml',
        'views/menu.xml',
        
        # Views mới - AI Minimalist (load sau)
        # 'views/attendance_ai_views_minimal.xml',
        # 'views/salary_ai_views_minimal.xml',
    ],
    'demo': [
        'data/hr_demo_data.xml',
        'data/demo_departments_employees.xml',
    ],
    'assets': {
        'web.assets_backend': [
            # CSS - Minimalist Design (NEW - Load First)
            'fitdnu_hr_ai/static/src/css/minimalist.css',
            
            # JS
            'fitdnu_hr_ai/static/src/js/webcam_widget.js',
            'fitdnu_hr_ai/static/src/js/ui_enhancements.js',
            'fitdnu_hr_ai/static/src/js/control_panel_domain_patch.js',
            
            # XML
            'fitdnu_hr_ai/static/src/xml/webcam_template.xml',
        ],
    },
    'images': ['static/description/banner.png'],
    'installable': True,
    'application': True,
    'auto_install': False,
}
