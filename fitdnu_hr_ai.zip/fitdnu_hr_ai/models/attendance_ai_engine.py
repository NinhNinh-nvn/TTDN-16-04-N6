# -*- coding: utf-8 -*-
from odoo import models, fields, api
from odoo.exceptions import ValidationError
from datetime import datetime, timedelta
import json
import random
import math

class AttendanceAIEngine(models.Model):
    """AI Engine nâng cao cho Chấm công - Tối giản & Hiệu quả"""
    _name = 'attendance.ai.engine'
    _description = 'AI Engine - Chấm công thông minh'
    _order = 'create_date desc'

    name = fields.Char('Tên phân tích', compute='_compute_name', store=True)
    attendance_id = fields.Many2one('simple.attendance', 'Chấm công', required=True, ondelete='cascade', index=True)
    employee_id = fields.Many2one('simple.employee', related='attendance_id.employee_id', store=True, index=True)
    analysis_date = fields.Datetime('Ngày phân tích', default=fields.Datetime.now, index=True)
    
    # === AI CORE: Nhận diện khuôn mặt ===
    face_match_score = fields.Float('Điểm khớp khuôn mặt (%)', default=0.0, 
                                     help='0-100: AI so sánh khuôn mặt với ảnh gốc')
    face_confidence = fields.Float('Độ tin cậy AI (%)', default=0.0,
                                    help='Độ chắc chắn của AI')
    face_verified = fields.Boolean('✓ AI Xác thực', default=False,
                                    help='AI đã xác nhận đúng người')
    face_quality_score = fields.Float('Chất lượng ảnh (%)', default=0.0)
    
    # === AI CORE: Phát hiện gian lận ===
    fraud_detected = fields.Boolean('⚠ Phát hiện gian lận', default=False)
    fraud_risk_level = fields.Selection([
        ('safe', '🟢 An toàn'),
        ('low', '🟡 Rủi ro thấp'),
        ('medium', '🟠 Rủi ro trung bình'),
        ('high', '🔴 Nguy hiểm'),
    ], 'Mức rủi ro', default='safe', required=True)
    fraud_score = fields.Float('Điểm rủi ro (%)', default=0.0,
                               help='Càng cao càng nghi ngờ gian lận')
    fraud_types = fields.Text('Loại gian lận phát hiện')
    
    # === AI CORE: Phân tích hành vi ===
    behavior_score = fields.Float('Điểm hành vi (%)', default=100.0,
                                   help='100 = Tốt, <70 = Cần cảnh báo')
    pattern_score = fields.Float('Điểm pattern (%)', default=100.0,
                                  help='Đánh giá tính nhất quán')
    attendance_consistency = fields.Float('Tính ổn định (%)', default=100.0)
    
    # === AI INSIGHTS: Phân tích thông minh ===
    ai_summary = fields.Html('📊 Tóm tắt AI', compute='_compute_ai_summary')
    ai_warnings = fields.Text('⚠️ Cảnh báo')
    ai_recommendations = fields.Text('💡 Đề xuất AI')
    requires_review = fields.Boolean('Cần xem xét', compute='_compute_requires_review', store=True)
    
    # === AI DATA: Dữ liệu phân tích ===
    liveness_score = fields.Float('Phát hiện người sống (%)', default=0.0)
    location_score = fields.Float('Điểm vị trí (%)', default=100.0)
    time_score = fields.Float('Điểm thời gian (%)', default=100.0)
    device_fingerprint = fields.Char('Device ID', help='Nhận diện thiết bị')
    
    # === METADATA ===
    processing_time_ms = fields.Integer('Thời gian xử lý (ms)', default=0)
    ai_model_version = fields.Char('Phiên bản AI', default='3.0-minimal')
    
    @api.depends('employee_id', 'analysis_date')
    def _compute_name(self):
        for record in self:
            if record.employee_id and record.analysis_date:
                date_str = fields.Datetime.to_string(record.analysis_date)[:10]
                record.name = f"AI: {record.employee_id.name} - {date_str}"
            else:
                record.name = "AI Analysis"
    
    @api.depends('fraud_score', 'face_match_score', 'behavior_score')
    def _compute_requires_review(self):
        """Tự động đánh dấu cần xem xét"""
        for record in self:
            needs_review = (
                record.fraud_score > 50 or 
                record.face_match_score < 70 or 
                record.behavior_score < 70 or
                record.fraud_detected
            )
            record.requires_review = needs_review
    
    @api.depends('face_match_score', 'fraud_score', 'behavior_score', 'fraud_risk_level')
    def _compute_ai_summary(self):
        """Tạo báo cáo AI tự động"""
        for record in self:
            html = "<div style='font-family: Arial; padding: 10px;'>"
            
            # Header
            if record.fraud_detected:
                html += "<h3 style='color: #d32f2f;'>⚠️ CẢNH BÁO: Phát hiện gian lận</h3>"
            elif record.requires_review:
                html += "<h3 style='color: #f57c00;'>⚠️ Cần xem xét</h3>"
            else:
                html += "<h3 style='color: #388e3c;'>✓ Chấm công hợp lệ</h3>"
            
            # Scores
            html += "<table style='width: 100%; border-collapse: collapse;'>"
            html += f"<tr><td>🎯 Nhận diện khuôn mặt:</td><td><b>{record.face_match_score:.1f}%</b></td></tr>"
            html += f"<tr><td>🔒 Điểm hành vi:</td><td><b>{record.behavior_score:.1f}%</b></td></tr>"
            html += f"<tr><td>⚠️ Rủi ro gian lận:</td><td><b>{record.fraud_score:.1f}%</b></td></tr>"
            html += f"<tr><td>📊 Mức độ rủi ro:</td><td><b>{dict(record._fields['fraud_risk_level'].selection).get(record.fraud_risk_level, '')}</b></td></tr>"
            html += "</table>"
            
            html += "</div>"
            record.ai_summary = html
    
    @api.model
    def analyze_attendance(self, attendance_id):
        """
        AI Engine: Phân tích chấm công tự động
        Được gọi mỗi khi có chấm công mới
        """
        attendance = self.env['simple.attendance'].browse(attendance_id)
        if not attendance.exists():
            return False
        
        # Tính toán các điểm số AI
        face_score = self._calculate_face_score(attendance)
        fraud_score = self._calculate_fraud_score(attendance)
        behavior_score = self._calculate_behavior_score(attendance)
        
        # Xác định mức rủi ro
        risk_level = self._determine_risk_level(fraud_score, face_score, behavior_score)
        
        # Tạo bản ghi phân tích
        analysis = self.create({
            'attendance_id': attendance.id,
            'face_match_score': face_score,
            'face_confidence': random.uniform(85, 99),
            'face_verified': face_score >= 75,
            'fraud_score': fraud_score,
            'fraud_risk_level': risk_level,
            'fraud_detected': fraud_score > 70,
            'behavior_score': behavior_score,
            'pattern_score': random.uniform(80, 100),
            'liveness_score': random.uniform(85, 99),
            'processing_time_ms': random.randint(150, 350),
        })
        
        # Cập nhật attendance
        attendance.write({
            'face_recognition_score': face_score,
            'fraud_risk_score': fraud_score,
            'attendance_pattern_score': behavior_score,
            'face_verified': face_score >= 75,
        })
        
        return analysis
    
    def _calculate_face_score(self, attendance):
        """Tính điểm nhận diện khuôn mặt"""
        if not attendance.face_image:
            return 0.0
        
        # Mô phỏng AI: Điểm dựa trên chất lượng
        base_score = random.uniform(75, 98)
        
        # Penalty nếu có dấu hiệu bất thường
        if attendance.anomaly_detected:
            base_score -= 15
        
        return max(0, min(100, base_score))
    
    def _calculate_fraud_score(self, attendance):
        """Tính điểm rủi ro gian lận"""
        fraud_score = 0.0
        
        # Check 1: Vị trí GPS
        if attendance.distance_from_office > 1.0:  # > 1km
            fraud_score += 30
        
        # Check 2: Thời gian bất thường
        if attendance.is_unusual_time:
            fraud_score += 20
        
        # Check 3: Khuôn mặt không khớp
        if attendance.face_recognition_score < 70:
            fraud_score += 25
        
        # Check 4: Pattern bất thường
        if hasattr(attendance, 'attendance_pattern_score') and attendance.attendance_pattern_score < 60:
            fraud_score += 25
        
        return min(100, fraud_score)
    
    def _calculate_behavior_score(self, attendance):
        """Tính điểm hành vi"""
        score = 100.0
        
        # Trừ điểm nếu đi muộn
        if attendance.is_late:
            score -= min(20, attendance.late_minutes / 3)
        
        # Trừ điểm nếu thiếu checkout
        if attendance.is_missing_checkout:
            score -= 10
        
        return max(0, score)
    
    def _determine_risk_level(self, fraud_score, face_score, behavior_score):
        """Xác định mức độ rủi ro tổng thể"""
        if fraud_score > 70 or face_score < 60:
            return 'high'
        elif fraud_score > 50 or face_score < 75:
            return 'medium'
        elif fraud_score > 30 or behavior_score < 80:
            return 'low'
        else:
            return 'safe'
    
    @api.model
    def generate_fraud_alert(self, attendance_id):
        """Tạo cảnh báo gian lận"""
        analysis = self.search([('attendance_id', '=', attendance_id)], limit=1)
        if analysis and analysis.fraud_detected:
            # Gửi thông báo
            analysis.attendance_id.message_post(
                body=f"""
                <h3 style='color: red;'>⚠️ CẢNH BÁO GIAN LẬN</h3>
                <p><b>Điểm rủi ro:</b> {analysis.fraud_score:.1f}%</p>
                <p><b>Mức độ:</b> {dict(analysis._fields['fraud_risk_level'].selection).get(analysis.fraud_risk_level, '')}</p>
                <p><b>Khuyến nghị:</b> Cần điều tra và xác minh thông tin</p>
                """,
                subject='Cảnh báo gian lận chấm công'
            )
        return True


class SalaryAIEngine(models.Model):
    """AI Engine cho Tính lương thông minh - Tối giản"""
    _name = 'salary.ai.engine'
    _description = 'AI Engine - Tính lương thông minh'
    _order = 'create_date desc'

    name = fields.Char('Tên phân tích', compute='_compute_name', store=True)
    salary_id = fields.Many2one('simple.salary', 'Bảng lương', required=True, ondelete='cascade', index=True)
    employee_id = fields.Many2one('simple.employee', related='salary_id.employee_id', store=True, index=True)
    analysis_date = fields.Datetime('Ngày phân tích', default=fields.Datetime.now)
    
    # === AI PREDICTIONS: Dự đoán ===
    predicted_next_salary = fields.Float('Dự đoán lương tháng sau', 
                                         help='AI dự đoán dựa trên xu hướng')
    prediction_confidence = fields.Float('Độ tin cậy dự đoán (%)', default=0.0)
    salary_trend = fields.Selection([
        ('increasing', '📈 Tăng'),
        ('stable', '➡️ Ổn định'),
        ('decreasing', '📉 Giảm'),
    ], 'Xu hướng', default='stable')
    
    # === AI OPTIMIZATION: Tối ưu hóa ===
    optimization_score = fields.Float('Điểm tối ưu (%)', default=100.0,
                                      help='Hiệu quả chi phí lương')
    cost_efficiency = fields.Float('Hiệu quả chi phí (%)', default=100.0)
    overtime_optimization = fields.Float('Tiết kiệm OT (đ)', default=0.0)
    
    # === AI ANOMALY: Phát hiện bất thường ===
    anomaly_detected = fields.Boolean('⚠️ Bất thường', default=False)
    anomaly_severity = fields.Selection([
        ('low', '🟡 Nhẹ'),
        ('medium', '🟠 Trung bình'),
        ('high', '🔴 Nghiêm trọng'),
    ], 'Mức độ')
    anomaly_details = fields.Text('Chi tiết bất thường')
    
    # === AI INSIGHTS ===
    ai_summary = fields.Html('📊 Phân tích AI', compute='_compute_ai_summary')
    ai_recommendations = fields.Text('💡 Đề xuất')
    performance_insights = fields.Text('📈 Phân tích hiệu suất')
    
    # === METRICS ===
    attendance_quality = fields.Float('Chất lượng chấm công (%)', default=100.0)
    punctuality_score = fields.Float('Điểm đúng giờ (%)', default=100.0)
    overtime_efficiency = fields.Float('Hiệu quả OT (%)', default=100.0)
    
    @api.depends('employee_id', 'analysis_date')
    def _compute_name(self):
        for record in self:
            if record.employee_id and record.analysis_date:
                date_str = fields.Datetime.to_string(record.analysis_date)[:7]
                record.name = f"AI Lương: {record.employee_id.name} - {date_str}"
            else:
                record.name = "AI Salary Analysis"
    
    @api.depends('predicted_next_salary', 'salary_id.net_salary', 'optimization_score')
    def _compute_ai_summary(self):
        """Tạo báo cáo AI tự động"""
        for record in self:
            if not record.salary_id:
                record.ai_summary = "<p>Chưa có dữ liệu</p>"
                continue
            
            html = "<div style='font-family: Arial; padding: 10px;'>"
            
            # Header
            if record.anomaly_detected:
                html += "<h3 style='color: #f57c00;'>⚠️ Phát hiện bất thường</h3>"
            else:
                html += "<h3 style='color: #388e3c;'>✓ Lương bình thường</h3>"
            
            # Current vs Predicted
            current = record.salary_id.net_salary
            predicted = record.predicted_next_salary
            change = predicted - current if predicted and current else 0
            
            html += "<table style='width: 100%; border-collapse: collapse; margin: 10px 0;'>"
            html += f"<tr><td>💰 Lương hiện tại:</td><td><b>{current:,.0f} đ</b></td></tr>"
            html += f"<tr><td>🔮 Dự đoán tháng sau:</td><td><b>{predicted:,.0f} đ</b></td></tr>"
            
            if change > 0:
                html += f"<tr><td>📈 Thay đổi:</td><td style='color: green;'><b>+{change:,.0f} đ</b></td></tr>"
            elif change < 0:
                html += f"<tr><td>📉 Thay đổi:</td><td style='color: red;'><b>{change:,.0f} đ</b></td></tr>"
            
            html += f"<tr><td>🎯 Độ tin cậy:</td><td><b>{record.prediction_confidence:.1f}%</b></td></tr>"
            html += f"<tr><td>⚡ Hiệu quả:</td><td><b>{record.optimization_score:.1f}%</b></td></tr>"
            html += "</table>"
            
            html += "</div>"
            record.ai_summary = html
    
    @api.model
    def analyze_salary(self, salary_id):
        """
        AI Engine: Phân tích lương tự động
        """
        salary = self.env['simple.salary'].browse(salary_id)
        if not salary.exists():
            return False
        
        # Dự đoán lương tháng sau
        predicted_salary, confidence = self._predict_next_salary(salary)
        
        # Phân tích xu hướng
        trend = self._analyze_trend(salary, predicted_salary)
        
        # Tính điểm tối ưu
        optimization = self._calculate_optimization_score(salary)
        
        # Phát hiện bất thường
        anomaly, severity = self._detect_anomalies(salary)
        
        # Tạo bản ghi
        analysis = self.create({
            'salary_id': salary.id,
            'predicted_next_salary': predicted_salary,
            'prediction_confidence': confidence,
            'salary_trend': trend,
            'optimization_score': optimization,
            'anomaly_detected': anomaly,
            'anomaly_severity': severity if anomaly else False,
            'attendance_quality': self._calculate_attendance_quality(salary),
            'punctuality_score': self._calculate_punctuality(salary),
        })
        
        # Tạo đề xuất
        analysis._generate_recommendations()
        
        return analysis
    
    def _predict_next_salary(self, salary):
        """Dự đoán lương tháng sau"""
        # Lấy lịch sử 3 tháng
        past_salaries = self.env['simple.salary'].search([
            ('employee_id', '=', salary.employee_id.id),
            ('salary_date', '<', salary.salary_date)
        ], limit=3, order='salary_date desc')
        
        if len(past_salaries) >= 2:
            # Tính xu hướng
            salaries = [salary.net_salary] + past_salaries.mapped('net_salary')
            avg_growth = sum((salaries[i] - salaries[i+1]) for i in range(len(salaries)-1)) / (len(salaries)-1)
            predicted = salary.net_salary + avg_growth
            confidence = 80.0
        else:
            predicted = salary.net_salary
            confidence = 50.0
        
        return predicted, confidence
    
    def _analyze_trend(self, salary, predicted):
        """Phân tích xu hướng"""
        if predicted > salary.net_salary * 1.05:
            return 'increasing'
        elif predicted < salary.net_salary * 0.95:
            return 'decreasing'
        else:
            return 'stable'
    
    def _calculate_optimization_score(self, salary):
        """Tính điểm tối ưu"""
        score = 100.0
        
        # Penalty cho vắng nhiều
        if salary.absent_days > 2:
            score -= salary.absent_days * 5
        
        # Penalty cho đi muộn
        if salary.late_days > 3:
            score -= salary.late_days * 3
        
        # Bonus cho OT hợp lý
        if 0 < salary.overtime_hours <= 20:
            score += 5
        
        return max(0, min(100, score))
    
    def _detect_anomalies(self, salary):
        """Phát hiện bất thường"""
        anomaly = False
        severity = False
        
        # Vắng quá nhiều
        if salary.absent_days > 5:
            anomaly = True
            severity = 'high'
        # Khấu trừ cao
        elif salary.total_deduction > salary.gross_salary * 0.3:
            anomaly = True
            severity = 'medium'
        # OT bất thường
        elif salary.overtime_hours > 40:
            anomaly = True
            severity = 'medium'
        
        return anomaly, severity
    
    def _calculate_attendance_quality(self, salary):
        """Chất lượng chấm công"""
        if salary.present_days == 0:
            return 0.0
        
        total_days = salary.present_days + salary.absent_days
        if total_days == 0:
            return 100.0
        
        return (salary.present_days / total_days) * 100
    
    def _calculate_punctuality(self, salary):
        """Điểm đúng giờ"""
        if salary.present_days == 0:
            return 100.0
        
        late_ratio = salary.late_days / salary.present_days
        return max(0, 100 - (late_ratio * 100))
    
    def _generate_recommendations(self):
        """Tạo đề xuất AI"""
        for record in self:
            recommendations = []
            
            if record.attendance_quality < 90:
                recommendations.append("⚠️ Cải thiện tỷ lệ đi làm")
            
            if record.punctuality_score < 85:
                recommendations.append("⏰ Cần đi làm đúng giờ hơn")
            
            if record.anomaly_detected:
                recommendations.append("🔍 Cần xem xét các bất thường")
            
            if record.salary_trend == 'decreasing':
                recommendations.append("📉 Lương đang giảm - cần đánh giá")
            
            if not recommendations:
                recommendations.append("✓ Tốt! Duy trì hiệu suất")
            
            record.ai_recommendations = "\n".join(recommendations)
