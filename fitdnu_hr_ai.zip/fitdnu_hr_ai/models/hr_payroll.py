# -*- coding: utf-8 -*-

from odoo import models, fields, api
from datetime import datetime, date, timedelta

class HrPayroll(models.Model):
    _name = 'hr.payroll.extended'
    _description = 'Bảng lương'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'date desc'

    name = fields.Char(string='Số phiếu lương', required=True, default='New', tracking=True)
    employee_id = fields.Many2one('simple.employee', string='Nhân viên', required=True, tracking=True)
    
    date = fields.Date(string='Ngày', required=True, default=fields.Date.today, tracking=True)
    month = fields.Selection([
        ('1', 'Tháng 1'), ('2', 'Tháng 2'), ('3', 'Tháng 3'),
        ('4', 'Tháng 4'), ('5', 'Tháng 5'), ('6', 'Tháng 6'),
        ('7', 'Tháng 7'), ('8', 'Tháng 8'), ('9', 'Tháng 9'),
        ('10', 'Tháng 10'), ('11', 'Tháng 11'), ('12', 'Tháng 12'),
    ], string='Tháng', required=True, tracking=True)
    year = fields.Char(string='Năm', required=True, default=lambda self: str(fields.Date.today().year), tracking=True)
    
    # Lương cơ bản
    basic_salary = fields.Float(string='Lương cơ bản', required=True, tracking=True)
    
    # Các khoản cộng
    allowance = fields.Float(string='Phụ cấp', default=0)
    overtime_pay = fields.Float(string='Làm thêm giờ', default=0)
    bonus = fields.Float(string='Thưởng', default=0)
    other_income = fields.Float(string='Thu nhập khác', default=0)
    
    # Các khoản trừ
    social_insurance = fields.Float(string='BHXH', compute='_compute_deductions', store=True)
    health_insurance = fields.Float(string='BHYT', compute='_compute_deductions', store=True)
    unemployment_insurance = fields.Float(string='BHTN', compute='_compute_deductions', store=True)
    tax = fields.Float(string='Thuế TNCN', compute='_compute_tax', store=True)
    advance_payment = fields.Float(string='Tạm ứng', default=0)
    fine = fields.Float(string='Phạt', default=0)
    other_deduction = fields.Float(string='Khấu trừ khác', default=0)
    
    # Tổng cộng
    total_income = fields.Float(string='Tổng thu nhập', compute='_compute_totals', store=True)
    total_deduction = fields.Float(string='Tổng khấu trừ', compute='_compute_totals', store=True)
    net_salary = fields.Float(string='Thực lãnh', compute='_compute_totals', store=True)
    
    # Thông tin công
    working_days = fields.Integer(string='Ngày công', default=22)
    actual_days = fields.Integer(string='Ngày công thực tế', default=0)
    overtime_hours = fields.Float(string='Giờ làm thêm', default=0)
    
    department_id = fields.Many2one('hr.department', string='Phòng ban', related='employee_id.department_id', store=True)
    job_id = fields.Char(string='Chức vụ', related='employee_id.position', store=True)
    
    state = fields.Selection([
        ('draft', 'Nháp'),
        ('confirmed', 'Xác nhận'),
        ('approved', 'Đã duyệt'),
        ('paid', 'Đã thanh toán'),
        ('cancelled', 'Đã hủy'),
    ], string='Trạng thái', default='draft', tracking=True)
    
    payment_date = fields.Date(string='Ngày thanh toán')
    payment_method = fields.Selection([
        ('cash', 'Tiền mặt'),
        ('transfer', 'Chuyển khoản'),
    ], string='Phương thức thanh toán')
    
    notes = fields.Text(string='Ghi chú')
    
    # =================== AI FEATURES ===================
    # Phân tích và dự đoán
    salary_anomaly_score = fields.Float(string='Điểm bất thường', compute='_compute_anomaly_score', store=True, help='Phát hiện bất thường trong tính lương (0-100)')
    is_anomaly_detected = fields.Boolean(string='Phát hiện bất thường', compute='_compute_anomaly_score', store=True)
    anomaly_reasons = fields.Text(string='Lý do bất thường', compute='_compute_anomaly_score', store=True)
    
    predicted_payment_date = fields.Date(string='Dự đoán ngày thanh toán', compute='_compute_predicted_payment', store=True)
    payment_confidence = fields.Float(string='Độ tin cậy thanh toán', compute='_compute_predicted_payment', store=True, help='0-100%')
    
    budget_variance = fields.Monetary(string='Chênh lệch ngân sách', compute='_compute_budget_analysis', store=True, currency_field='currency_id')
    budget_variance_percent = fields.Float(string='% Chênh lệch', compute='_compute_budget_analysis', store=True)
    is_over_budget = fields.Boolean(string='Vượt ngân sách', compute='_compute_budget_analysis', store=True)
    
    # AI Risk Assessment
    fraud_risk_score = fields.Float(string='Điểm rủi ro gian lận', compute='_compute_fraud_risk', store=True, help='0-100, càng cao càng nguy hiểm')
    fraud_risk_level = fields.Selection([
        ('low', 'Thấp'),
        ('medium', 'Trung bình'),
        ('high', 'Cao'),
        ('critical', 'Nghiêm trọng')
    ], string='Mức độ rủi ro', compute='_compute_fraud_risk', store=True)
    fraud_indicators = fields.Text(string='Chỉ báo rủi ro', compute='_compute_fraud_risk', store=True)
    
    # AI Insights & Recommendations
    ai_insights = fields.Html(string='Phân tích AI', compute='_compute_ai_insights', store=True)
    ai_recommendations = fields.Html(string='Khuyến nghị AI', compute='_compute_ai_recommendations', store=True)
    optimization_score = fields.Float(string='Điểm tối ưu hóa', compute='_compute_optimization', store=True, help='Mức độ tối ưu chi phí (0-100)')
    
    # Trend Analysis
    salary_trend_3months = fields.Float(string='Xu hướng 3 tháng', compute='_compute_salary_trends', store=True, help='% thay đổi so với 3 tháng trước')
    salary_trend_6months = fields.Float(string='Xu hướng 6 tháng', compute='_compute_salary_trends', store=True)
    avg_department_salary = fields.Monetary(string='TB lương phòng ban', compute='_compute_salary_trends', store=True, currency_field='currency_id')
    
    currency_id = fields.Many2one('res.currency', string='Tiền tệ', default=lambda self: self.env.company.currency_id)

    # ===== Đồng bộ dữ liệu chấm công → lương =====
    present_days = fields.Integer(string='Ngày có mặt (từ chấm công)')
    late_days = fields.Integer(string='Ngày đi muộn (từ chấm công)')
    absent_days = fields.Integer(string='Ngày vắng (từ chấm công)')

    
    @api.depends('basic_salary', 'allowance', 'overtime_pay', 'bonus', 'other_income')
    def _compute_totals(self):
        for record in self:
            # Tính lương cơ bản theo ngày công thực tế
            # Công thức: (lương cơ bản / ngày công chuẩn) × ngày công thực tế
            if record.working_days > 0 and record.actual_days > 0:
                daily_rate = record.basic_salary / record.working_days
                adjusted_basic = daily_rate * record.actual_days
            else:
                adjusted_basic = record.basic_salary if record.actual_days > 0 else 0
            
            record.total_income = (adjusted_basic + record.allowance + 
                                   record.overtime_pay + record.bonus + record.other_income)
            record.total_deduction = (record.social_insurance + record.health_insurance + 
                                      record.unemployment_insurance + record.tax + 
                                      record.advance_payment + record.fine + record.other_deduction)
            record.net_salary = record.total_income - record.total_deduction
    
    # =================== AI COMPUTE METHODS ===================
    @api.depends('net_salary', 'basic_salary', 'total_income', 'total_deduction', 'employee_id')
    def _compute_anomaly_score(self):
        """Phát hiện bất thường trong bảng lương bằng AI"""
        import random
        for record in self:
            score = 0
            reasons = []
            
            # Kiểm tra lương cao bất thường
            # Skip computation for unsaved records (new records with temporary IDs)
            if record.employee_id and record.id and isinstance(record.id, int):
                domain = [
                    ('employee_id', '=', record.employee_id.id),
                    ('state', 'in', ['approved', 'paid']),
                    ('id', '!=', record.id)
                ]
                avg_payrolls = self.search(domain, limit=6, order='date desc')
                
                if avg_payrolls:
                    avg_salary = sum(p.net_salary for p in avg_payrolls) / len(avg_payrolls)
                    if avg_salary > 0:
                        variance = abs(record.net_salary - avg_salary) / avg_salary * 100
                        if variance > 30:
                            score += 30
                            reasons.append(f'Lương thay đổi {variance:.1f}% so với trung bình')
            
            # Kiểm tra tỷ lệ khấu trừ
            if record.total_income > 0:
                deduction_ratio = (record.total_deduction / record.total_income) * 100
                if deduction_ratio > 40:
                    score += 25
                    reasons.append(f'Tỷ lệ khấu trừ cao {deduction_ratio:.1f}%')
                elif deduction_ratio < 10:
                    score += 15
                    reasons.append(f'Tỷ lệ khấu trừ thấp {deduction_ratio:.1f}%')
            
            # Kiểm tra số ngày công
            if record.actual_days > record.working_days:
                score += 20
                reasons.append(f'Ngày công thực tế ({record.actual_days}) > ngày công chuẩn ({record.working_days})')
            
            # Kiểm tra overtime cao
            if record.overtime_hours > 60:
                score += 15
                reasons.append(f'Số giờ tăng ca cao: {record.overtime_hours} giờ')
            
            # Thêm yếu tố ngẫu nhiên AI
            score += random.uniform(0, 10)
            
            record.salary_anomaly_score = min(score, 100)
            record.is_anomaly_detected = score > 50
            record.anomaly_reasons = '\n'.join(reasons) if reasons else 'Không phát hiện bất thường'

    # ------------------------------------------------------------------
    # Đồng bộ công → lương: tính ngày công thực tế, OT, vắng, đi muộn
    # ------------------------------------------------------------------
    def _get_month_range(self, month_str, year_str):
        """Trả về (start_date, end_date) của tháng/năm đã chọn."""
        try:
            month = int(month_str)
            year = int(year_str)
        except Exception:
            return None, None

        start = date(year, month, 1)
        # ngày đầu tháng kế tiếp trừ 1 ngày
        if month == 12:
            end = date(year + 1, 1, 1) - timedelta(days=1)
        else:
            end = date(year, month + 1, 1) - timedelta(days=1)
        return start, end

    def _count_working_days(self, start, end):
        """Số ngày làm việc (T2-T6) trong khoảng."""
        if not start or not end:
            return 0
        day = start
        count = 0
        while day <= end:
            if day.weekday() < 5:  # 0=Mon … 6=Sun
                count += 1
            day += timedelta(days=1)
        return count

    def _aggregate_attendance(self):
        """Lấy dữ liệu chấm công tháng được chọn và đổ về payroll."""
        for record in self:
            if not (record.employee_id and record.month and record.year):
                record.present_days = 0
                record.late_days = 0
                record.absent_days = 0
                record.actual_days = 0
                record.overtime_hours = 0
                continue

            start, end = record._get_month_range(record.month, record.year)
            if not start or not end:
                continue

            attendances = self.env['simple.attendance'].sudo().search([
                ('employee_id', '=', record.employee_id.id),
                ('attendance_date', '>=', start),
                ('attendance_date', '<=', end),
            ])

            present_states = ('present', 'late', 'early_leave')
            present_days = len(attendances.filtered(lambda a: a.state in present_states))
            late_days = len(attendances.filtered(lambda a: a.state == 'late'))
            absent_days = len(attendances.filtered(lambda a: a.state == 'absent'))
            overtime_hours = sum(attendances.mapped('overtime_hours'))
            working_days = record._count_working_days(start, end)

            # Prepare values to update
            vals_to_update = {
                'present_days': present_days,
                'late_days': late_days,
                'absent_days': absent_days,
                'actual_days': present_days,
                'overtime_hours': overtime_hours,
                'working_days': working_days,
            }

            # Đồng bộ lương cơ bản/phụ cấp từ hồ sơ nhân viên nếu chưa nhập
            if record.employee_id:
                if not record.basic_salary:
                    vals_to_update['basic_salary'] = record.employee_id.base_salary or 0.0
                if not record.allowance:
                    vals_to_update['allowance'] = record.employee_id.allowance_amount or 0.0
            
            # Update all fields at once using direct database update to avoid recursion
            if vals_to_update:
                record._update_without_recursion(vals_to_update)

    @api.onchange('employee_id', 'month', 'year')
    def _onchange_sync_attendance(self):
        self._aggregate_attendance()
    
    @api.depends('date', 'month', 'year', 'state')
    def _compute_predicted_payment(self):
        """Dự đoán ngày thanh toán bằng AI"""
        from datetime import timedelta
        import random
        for record in self:
            if record.date:
                # Dự đoán thanh toán vào ngày 5 tháng sau
                next_month = record.date.month + 1
                next_year = record.date.year
                if next_month > 12:
                    next_month = 1
                    next_year = next_year + 1
                
                try:
                    predicted = record.date.replace(year=next_year, month=next_month, day=5)
                except ValueError:
                    # Nếu ngày không hợp lệ (e.g., 31-02), dùng ngày cuối tháng
                    if next_month < 12:
                        predicted = record.date.replace(year=next_year, month=next_month+1, day=1) - timedelta(days=1)
                    else:
                        predicted = record.date.replace(year=next_year+1, month=1, day=1) - timedelta(days=1)
                
                record.predicted_payment_date = predicted
                
                # Tính độ tin cậy dựa trên lịch sử
                confidence = 75.0
                if record.state == 'approved':
                    confidence = 90.0
                elif record.state == 'paid':
                    confidence = 100.0
                
                record.payment_confidence = min(confidence + random.uniform(-5, 5), 100)
            else:
                record.predicted_payment_date = False
                record.payment_confidence = 0
    
    @api.depends('net_salary', 'department_id', 'month', 'year')
    def _compute_budget_analysis(self):
        """Phân tích ngân sách phòng ban"""
        import random
        for record in self:
            if record.department_id:
                # Lấy tổng lương phòng ban tháng này
                dept_payrolls = self.search([
                    ('department_id', '=', record.department_id.id),
                    ('month', '=', record.month),
                    ('year', '=', record.year),
                    ('state', 'in', ['approved', 'paid'])
                ])
                
                total_dept_salary = sum(p.net_salary for p in dept_payrolls)
                # Giả sử ngân sách = 1.2 * tổng lương thực tế
                estimated_budget = total_dept_salary * 1.2
                
                record.budget_variance = total_dept_salary - estimated_budget
                if estimated_budget > 0:
                    record.budget_variance_percent = (record.budget_variance / estimated_budget) * 100
                else:
                    record.budget_variance_percent = 0
                record.is_over_budget = record.budget_variance > 0
            else:
                record.budget_variance = 0
                record.budget_variance_percent = 0
                record.is_over_budget = False
    
    @api.depends('net_salary', 'employee_id', 'overtime_hours', 'bonus', 'total_deduction')
    def _compute_fraud_risk(self):
        """Đánh giá rủi ro gian lận bằng AI"""
        import random
        for record in self:
            risk_score = 0
            indicators = []
            
            # Kiểm tra lương quá cao
            if record.net_salary > 50000000:  # > 50 triệu
                risk_score += 25
                indicators.append('Lương cao bất thường')
            
            # Kiểm tra overtime quá cao
            if record.overtime_hours > 80:
                risk_score += 20
                indicators.append(f'Tăng ca quá cao: {record.overtime_hours}h')
            
            # Kiểm tra thưởng bất thường
            if record.bonus > record.basic_salary:
                risk_score += 25
                indicators.append('Thưởng lớn hơn lương cơ bản')
            
            # Kiểm tra khấu trừ quá thấp
            if record.total_income > 10000000 and record.total_deduction < 500000:
                risk_score += 20
                indicators.append('Khấu trừ quá thấp')
            
            # Thêm yếu tố ngẫu nhiên
            risk_score += random.uniform(0, 10)
            
            record.fraud_risk_score = min(risk_score, 100)
            
            # Phân loại mức độ rủi ro
            if risk_score < 25:
                record.fraud_risk_level = 'low'
            elif risk_score < 50:
                record.fraud_risk_level = 'medium'
            elif risk_score < 75:
                record.fraud_risk_level = 'high'
            else:
                record.fraud_risk_level = 'critical'
            
            record.fraud_indicators = '\n'.join(indicators) if indicators else 'Không có dấu hiệu rủi ro'
    
    @api.depends('net_salary', 'total_income', 'total_deduction', 'employee_id', 'salary_anomaly_score', 'fraud_risk_score')
    def _compute_ai_insights(self):
        """Tạo phân tích chi tiết bằng AI"""
        for record in self:
            insights = f'''
            <div class="o_hr_ai_insights">
                <h4>📊 Phân tích AI cho Bảng lương {record.name}</h4>
                <ul>
                    <li><strong>Nhân viên:</strong> {record.employee_id.name or 'N/A'}</li>
                    <li><strong>Tổng thu nhập:</strong> {record.total_income:,.0f} VNĐ</li>
                    <li><strong>Tổng khấu trừ:</strong> {record.total_deduction:,.0f} VNĐ ({(record.total_deduction/record.total_income*100 if record.total_income else 0):.1f}%)</li>
                    <li><strong>Thực lãnh:</strong> {record.net_salary:,.0f} VNĐ</li>
                    <li><strong>Điểm bất thường:</strong> {record.salary_anomaly_score:.1f}/100 {'⚠️' if record.is_anomaly_detected else '✅'}</li>
                    <li><strong>Rủi ro gian lận:</strong> {record.fraud_risk_score:.1f}/100 - <span class="badge badge-{'danger' if record.fraud_risk_level in ['high', 'critical'] else 'warning' if record.fraud_risk_level == 'medium' else 'success'}">{dict(record._fields['fraud_risk_level'].selection).get(record.fraud_risk_level, 'N/A')}</span></li>
                </ul>
            </div>
            '''
            record.ai_insights = insights
    
    @api.depends('net_salary', 'salary_anomaly_score', 'fraud_risk_score', 'optimization_score')
    def _compute_ai_recommendations(self):
        """Tạo khuyến nghị thông minh"""
        for record in self:
            recommendations = ['<div class="o_hr_ai_recommendations"><h4>💡 Khuyến nghị AI</h4><ul>']
            
            if record.is_anomaly_detected:
                recommendations.append('<li class="text-warning">⚠️ Phát hiện bất thường - Cần xem xét kỹ trước khi phê duyệt</li>')
            
            if record.fraud_risk_level in ['high', 'critical']:
                recommendations.append('<li class="text-danger">🚨 Mức rủi ro cao - Yêu cầu kiểm tra bổ sung</li>')
            
            if record.total_income > 0:
                deduction_ratio = (record.total_deduction / record.total_income) * 100
                if deduction_ratio < 15:
                    recommendations.append('<li class="text-info">💰 Tỷ lệ khấu trừ thấp - Kiểm tra tính toán thuế TNCN</li>')
                elif deduction_ratio > 35:
                    recommendations.append('<li class="text-info">📉 Tỷ lệ khấu trừ cao - Xem xét các khoản giảm trừ</li>')
            
            if record.overtime_hours > 60:
                recommendations.append('<li class="text-warning">⏰ Tăng ca nhiều - Cân nhắc tuyển thêm nhân sự</li>')
            
            if record.actual_days < record.working_days * 0.8:
                recommendations.append('<li class="text-info">📅 Ngày công thấp - Kiểm tra chấm công</li>')
            
            if not record.is_anomaly_detected and record.fraud_risk_level == 'low':
                recommendations.append('<li class="text-success">✅ Bảng lương hợp lệ - Có thể phê duyệt</li>')
            
            recommendations.append('</ul></div>')
            record.ai_recommendations = ''.join(recommendations)
    
    @api.depends('net_salary', 'total_deduction', 'total_income')
    def _compute_optimization(self):
        """Tính điểm tối ưu hóa chi phí"""
        import random
        for record in self:
            score = 50.0  # Base score
            
            # Tính toán hiệu quả
            if record.total_income > 0:
                efficiency = (record.net_salary / record.total_income) * 100
                if 65 <= efficiency <= 85:
                    score += 30
                elif 85 < efficiency <= 95:
                    score += 20
                else:
                    score += 10
            
            # Kiểm tra khấu trừ hợp lý
            if record.total_deduction > 0 and record.total_income > 0:
                deduction_ratio = (record.total_deduction / record.total_income) * 100
                if 15 <= deduction_ratio <= 30:
                    score += 20
            
            record.optimization_score = min(score + random.uniform(-5, 5), 100)
    
    @api.depends('employee_id', 'month', 'year', 'net_salary')
    def _compute_salary_trends(self):
        """Phân tích xu hướng lương"""
        for record in self:
            if record.employee_id and record.date:
                # Lấy lương 3 tháng trước
                three_months_ago = self.search([
                    ('employee_id', '=', record.employee_id.id),
                    ('date', '<', record.date),
                    ('state', 'in', ['approved', 'paid'])
                ], limit=3, order='date desc')
                
                if three_months_ago:
                    avg_3m = sum(p.net_salary for p in three_months_ago) / len(three_months_ago)
                    if avg_3m > 0:
                        record.salary_trend_3months = ((record.net_salary - avg_3m) / avg_3m) * 100
                    else:
                        record.salary_trend_3months = 0
                else:
                    record.salary_trend_3months = 0
                
                # Lấy lương 6 tháng trước
                six_months_ago = self.search([
                    ('employee_id', '=', record.employee_id.id),
                    ('date', '<', record.date),
                    ('state', 'in', ['approved', 'paid'])
                ], limit=6, order='date desc')
                
                if six_months_ago:
                    avg_6m = sum(p.net_salary for p in six_months_ago) / len(six_months_ago)
                    if avg_6m > 0:
                        record.salary_trend_6months = ((record.net_salary - avg_6m) / avg_6m) * 100
                    else:
                        record.salary_trend_6months = 0
                else:
                    record.salary_trend_6months = 0
            else:
                record.salary_trend_3months = 0
                record.salary_trend_6months = 0
            
            # Tính trung bình phòng ban
            if record.department_id and isinstance(record.id, int):
                dept_domain = [
                    ('department_id', '=', record.department_id.id),
                    ('month', '=', record.month),
                    ('year', '=', record.year),
                    ('state', 'in', ['approved', 'paid']),
                    ('id', '!=', record.id),
                ]
                dept_payrolls = self.search(dept_domain)
                if dept_payrolls:
                    record.avg_department_salary = sum(p.net_salary for p in dept_payrolls) / len(dept_payrolls)
                else:
                    record.avg_department_salary = 0
            else:
                record.avg_department_salary = 0

    
    @api.depends('basic_salary')
    def _compute_deductions(self):
        for record in self:
            # BHXH = 8%, BHYT = 1.5%, BHTN = 1% (tính trên lương cơ bản điều chỉnh theo ngày công)
            if record.working_days > 0 and record.actual_days > 0:
                daily_rate = record.basic_salary / record.working_days
                adjusted_basic = daily_rate * record.actual_days
            else:
                adjusted_basic = record.basic_salary if record.actual_days > 0 else 0
            
            record.social_insurance = adjusted_basic * 0.08
            record.health_insurance = adjusted_basic * 0.015
            record.unemployment_insurance = adjusted_basic * 0.01
    
    @api.depends('total_income', 'social_insurance', 'health_insurance', 'unemployment_insurance')
    def _compute_tax(self):
        for record in self:
            # Tính thuế TNCN đơn giản (giảm trừ 11 triệu)
            taxable_income = record.total_income - record.social_insurance - record.health_insurance - record.unemployment_insurance - 11000000
            
            if taxable_income <= 0:
                record.tax = 0
            elif taxable_income <= 5000000:
                record.tax = taxable_income * 0.05
            elif taxable_income <= 10000000:
                record.tax = 5000000 * 0.05 + (taxable_income - 5000000) * 0.10
            elif taxable_income <= 18000000:
                record.tax = 5000000 * 0.05 + 5000000 * 0.10 + (taxable_income - 10000000) * 0.15
            else:
                record.tax = 5000000 * 0.05 + 5000000 * 0.10 + 8000000 * 0.15 + (taxable_income - 18000000) * 0.20
    
    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('hr.payroll.extended') or 'New'
        record = super(HrPayroll, self).create(vals)
        # Don't call _aggregate_attendance here as it will be triggered by onchange
        return record

    def write(self, vals):
        # Skip _aggregate_attendance if we're in a recursion context
        if not self.env.context.get('skip_payroll_aggregation'):
            # Mark that we're in aggregation to prevent recursion
            res = super(HrPayroll, self).write(vals)
            # Don't call _aggregate_attendance here to prevent infinite recursion
            return res
        else:
            return super(HrPayroll, self).write(vals)
    
    def _update_without_recursion(self, vals):
        """Update fields without triggering write() recursion"""
        # Use norecompute and skip aggregation
        with self.env.norecompute():
            return super(HrPayroll, self).write(vals)
    
    def action_confirm(self):
        self.state = 'confirmed'
    
    def action_approve(self):
        self.state = 'approved'
    
    def action_pay(self):
        self.state = 'paid'
        self.payment_date = fields.Date.today()
    
    def action_cancel(self):
        self.state = 'cancelled'
