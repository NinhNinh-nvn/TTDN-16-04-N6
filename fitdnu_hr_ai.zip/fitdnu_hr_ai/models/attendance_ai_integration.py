# -*- coding: utf-8 -*-
from odoo import models, fields, api
from odoo.exceptions import ValidationError, UserError
from datetime import datetime, timedelta, time
import json
import math

class AttendanceAIFeatures(models.Model):
    """Tích hợp AI cho hệ thống chấm công"""
    _name = 'attendance.ai.features'
    _description = 'AI Features cho Chấm công'
    
    # Liveness Detection - Phát hiện người sống
    liveness_check = fields.Boolean('Kiểm tra liveness', default=True,
                                   help='Phát hiện ảnh sống vs ảnh chụp')
    liveness_score = fields.Float('Điểm liveness (0-100)', default=0.0)
    liveness_method = fields.Selection([
        ('eye_blink', 'Nhắp mắt'),
        ('head_turn', 'Quay đầu'),
        ('smile_detection', 'Nụ cười'),
        ('texture_analysis', 'Phân tích texture'),
        ('multi_channel', 'Đa kênh'),
    ], 'Phương pháp liveness')
    
    # Image Quality Analysis
    image_quality_score = fields.Float('Chất lượng ảnh (%)', default=0.0)
    brightness_level = fields.Float('Độ sáng (0-100)', default=0.0)
    contrast_level = fields.Float('Độ tương phản (0-100)', default=0.0)
    blur_detection = fields.Boolean('Phát hiện mờ', default=False)
    face_angle = fields.Float('Góc khuôn mặt (độ)', default=0.0)
    face_size = fields.Float('Kích thước khuôn mặt (%)', default=0.0)
    
    # Advanced Face Recognition
    facial_features = fields.Text('Đặc trưng khuôn mặt', help='JSON: landmark points')
    face_embeddings = fields.Binary('Face embeddings (vector)', attachment=True)
    euclidean_distance = fields.Float('Khoảng cách Euclidean', default=0.0,
                                     help='Thấp = giống nhau hơn')
    cosine_similarity = fields.Float('Cosine similarity (0-1)', default=0.0,
                                    help='Cao = giống nhau hơn')
    
    # Multi-Face Detection
    faces_detected_count = fields.Integer('Số khuôn mặt phát hiện', default=0)
    has_multiple_faces = fields.Boolean('Phát hiện nhiều người', default=False)
    occlusion_detected = fields.Boolean('Che phủ (kính, khẩu trang)', default=False)
    
    # Spoof Detection (Phát hiện giả mạo)
    spoof_detection_enabled = fields.Boolean('Bật phát hiện giả mạo', default=True)
    spoof_score = fields.Float('Điểm giả mạo (0-100)', default=0.0,
                              help='Cao = khả năng giả mạo cao')
    spoof_risk_level = fields.Selection([
        ('low', 'Thấp'),
        ('medium', 'Trung bình'),
        ('high', 'Cao'),
        ('very_high', 'Rất cao'),
    ], 'Mức rủi ro giả mạo', default='low')
    
    # Emotion Detection
    emotion_detected = fields.Selection([
        ('neutral', 'Bình thường'),
        ('happy', 'Vui'),
        ('sad', 'Buồn'),
        ('angry', 'Tức giận'),
        ('surprised', 'Bất ngờ'),
        ('fearful', 'Sợ hãi'),
        ('disgusted', 'Ghê tởm'),
    ], 'Cảm xúc')
    emotion_score = fields.Float('Điểm cảm xúc', default=0.0)
    
    # Age & Gender Verification
    age_estimation = fields.Integer('Ước tính tuổi', default=0)
    gender_detected = fields.Selection([
        ('male', 'Nam'),
        ('female', 'Nữ'),
        ('other', 'Khác'),
    ], 'Giới tính')
    age_gender_score = fields.Float('Điểm chính xác tuổi/giới tính (%)', default=0.0)
    
    # Real-time Processing Metrics
    processing_time_ms = fields.Float('Thời gian xử lý (ms)', default=0.0)
    api_response_time_ms = fields.Float('Thời gian API (ms)', default=0.0)
    total_time_ms = fields.Float('Tổng thời gian (ms)', default=0.0)


class AttendanceAIAnalysis(models.Model):
    """Phân tích AI cho chấm công"""
    _name = 'attendance.ai.analysis'
    _description = 'Phân tích AI Chấm công'
    
    attendance_id = fields.Many2one('simple.attendance', 'Chấm công', required=True, ondelete='cascade')
    analysis_date = fields.Datetime('Ngày phân tích', default=fields.Datetime.now)
    analysis_type = fields.Selection([
        ('real_time', 'Real-time'),
        ('batch', 'Batch processing'),
        ('periodic', 'Định kỳ'),
    ], 'Loại phân tích', default='real_time')
    
    # Risk Scoring Components
    facial_match_risk = fields.Float('Rủi ro khuôn mặt (%)', default=0.0)
    location_risk = fields.Float('Rủi ro vị trí (%)', default=0.0)
    timing_risk = fields.Float('Rủi ro thời gian (%)', default=0.0)
    pattern_risk = fields.Float('Rủi ro pattern (%)', default=0.0)
    spoof_risk = fields.Float('Rủi ro giả mạo (%)', default=0.0)
    liveness_risk = fields.Float('Rủi ro fake (%)', default=0.0)
    
    # Combined Risk Score
    overall_risk_score = fields.Float('Tổng rủi ro (%)', compute='_compute_overall_risk', store=True)
    
    # Recommendation
    recommendation = fields.Selection([
        ('approve', 'Phê duyệt'),
        ('review', 'Cần kiểm tra'),
        ('reject', 'Từ chối'),
        ('flag_for_investigation', 'Gắn cờ điều tra'),
    ], 'Khuyến nghị')
    recommendation_reason = fields.Text('Lý do khuyến nghị')
    
    # Investigation Flag
    flagged_for_investigation = fields.Boolean('Gắn cờ điều tra', default=False)
    investigation_priority = fields.Selection([
        ('low', 'Thấp'),
        ('medium', 'Trung bình'),
        ('high', 'Cao'),
        ('urgent', 'Khẩn cấp'),
    ], 'Ưu tiên')
    
    @api.depends('facial_match_risk', 'location_risk', 'timing_risk', 'pattern_risk', 'spoof_risk', 'liveness_risk')
    def _compute_overall_risk(self):
        for record in self:
            risks = [
                record.facial_match_risk,
                record.location_risk,
                record.timing_risk,
                record.pattern_risk,
                record.spoof_risk,
                record.liveness_risk,
            ]
            record.overall_risk_score = sum(risks) / len(risks) if risks else 0.0


class AttendanceAIDecision(models.Model):
    """Quyết định dựa trên AI cho chấm công"""
    _name = 'attendance.ai.decision'
    _description = 'Quyết định AI cho Chấm công'
    
    attendance_id = fields.Many2one('simple.attendance', 'Chấm công', required=True, ondelete='cascade')
    decision_date = fields.Datetime('Ngày quyết định', default=fields.Datetime.now)
    
    # Decision Result
    is_valid = fields.Boolean('Hợp lệ', default=True)
    confidence_score = fields.Float('Độ tin cậy (%)', default=0.0)
    
    # Decision Reasoning
    decision_reason = fields.Text('Lý do quyết định')
    decision_factors = fields.Text('Các yếu tố (JSON)', help='JSON array of decision factors')
    
    # Action Taken
    action_taken = fields.Selection([
        ('accepted', 'Chấp nhận'),
        ('pending_review', 'Chờ xem xét'),
        ('rejected', 'Từ chối'),
        ('escalated', 'Nâng cấp cho admin'),
    ], 'Hành động')
    
    reviewed_by = fields.Many2one('res.users', 'Người xem xét')
    reviewed_date = fields.Datetime('Ngày xem xét')
    review_notes = fields.Text('Ghi chú xem xét')
    
    # Appeal Process
    can_appeal = fields.Boolean('Có thể phản đối', default=True)
    appealed = fields.Boolean('Đã phản đối', default=False)
    appeal_reason = fields.Text('Lý do phản đối')
    appeal_status = fields.Selection([
        ('pending', 'Chờ xử lý'),
        ('approved', 'Phê duyệt'),
        ('rejected', 'Từ chối'),
    ], 'Trạng thái phản đối')


class AttendanceFraudAlert(models.Model):
    """Cảnh báo gian lận trong chấm công"""
    _name = 'attendance.fraud.alert'
    _description = 'Cảnh báo Gian lận Chấm công'
    
    attendance_id = fields.Many2one('simple.attendance', 'Chấm công', ondelete='cascade')
    employee_id = fields.Many2one('simple.employee', 'Nhân viên', required=True)
    alert_date = fields.Datetime('Ngày cảnh báo', default=fields.Datetime.now, index=True)
    
    # Alert Details
    alert_type = fields.Selection([
        ('proxy_attendance', 'Chấm công hộ'),
        ('face_spoofing', 'Spoofing khuôn mặt'),
        ('fake_location', 'Vị trí giả'),
        ('time_manipulation', 'Thao túng thời gian'),
        ('unusual_pattern', 'Pattern bất thường'),
        ('multiple_locations', 'Nhiều vị trí cùng lúc'),
        ('impossible_travel', 'Di chuyển không khả thi'),
        ('clock_manipulation', 'Thao túng giờ hệ thống'),
        ('data_tampering', 'Giả mạo dữ liệu'),
    ], 'Loại cảnh báo', required=True)
    
    severity = fields.Selection([
        ('low', 'Thấp'),
        ('medium', 'Trung bình'),
        ('high', 'Cao'),
        ('critical', 'Nghiêm trọng'),
    ], 'Mức độ', default='medium')
    
    description = fields.Text('Mô tả')
    evidence = fields.Text('Bằng chứng (JSON)')
    
    # Action Status
    status = fields.Selection([
        ('new', 'Mới'),
        ('acknowledged', 'Đã xác nhận'),
        ('under_investigation', 'Đang điều tra'),
        ('resolved', 'Đã giải quyết'),
        ('dismissed', 'Bác bỏ'),
    ], 'Trạng thái', default='new')
    
    investigated_by = fields.Many2one('res.users', 'Người điều tra')
    investigation_date = fields.Datetime('Ngày điều tra')
    investigation_notes = fields.Text('Ghi chú điều tra')
    
    # HR Decision
    hr_decision = fields.Selection([
        ('warning', 'Cảnh cáo'),
        ('suspension', 'Tạm dừng'),
        ('termination', 'Chấm dứt'),
        ('training', 'Đào tạo'),
        ('no_action', 'Không có hành động'),
    ], 'Quyết định HR')
    
    hr_notes = fields.Text('Ghi chú HR')

    def action_acknowledge(self):
        for rec in self:
            rec.status = 'acknowledged'
        return True

    def action_investigate(self):
        for rec in self:
            rec.status = 'under_investigation'
        return True

    def action_resolve(self):
        for rec in self:
            rec.status = 'resolved'
        return True


class AttendanceAIPrediction(models.Model):
    """Dự đoán AI cho chấm công"""
    _name = 'attendance.ai.prediction'
    _description = 'Dự đoán AI Chấm công'
    
    employee_id = fields.Many2one('simple.employee', 'Nhân viên', required=True, ondelete='cascade')
    prediction_date = fields.Date('Ngày dự đoán', default=fields.Date.today)
    prediction_period = fields.Selection([
        ('daily', 'Ngày'),
        ('weekly', 'Tuần'),
        ('monthly', 'Tháng'),
    ], 'Chu kỳ', default='daily')
    
    # Attendance Predictions
    predicted_attendance_rate = fields.Float('Tỷ lệ dự đoán (%)', default=0.0)
    predicted_late_risk = fields.Float('Rủi ro muộn (%)', default=0.0)
    predicted_absence_risk = fields.Float('Rủi ro vắng (%)', default=0.0)
    predicted_overtime_hours = fields.Float('Dự đoán OT (giờ)', default=0.0)
    
    # Historical Pattern
    avg_check_in_time = fields.Float('Giờ vào trung bình', default=0.0)
    avg_check_out_time = fields.Float('Giờ ra trung bình', default=0.0)
    avg_working_hours = fields.Float('Giờ làm trung bình', default=0.0)
    
    # Recommendation
    predicted_action = fields.Selection([
        ('none', 'Không hành động'),
        ('reminder', 'Nhắc nhở'),
        ('warning', 'Cảnh báo'),
        ('review', 'Xem xét'),
        ('escalate', 'Nâng cấp'),
    ], 'Hành động dự đoán', default='none')
    
    model_accuracy = fields.Float('Độ chính xác mô hình (%)', default=0.0)
    model_version = fields.Char('Phiên bản mô hình', default='1.0')
