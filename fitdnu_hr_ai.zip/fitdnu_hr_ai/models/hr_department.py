# -*- coding: utf-8 -*-
from odoo import models, fields, api
from datetime import datetime

class HRDepartment(models.Model):
    _name = 'hr.department'
    _description = 'Phòng Ban'
    _parent_name = 'parent_id'
    _parent_store = True
    _order = 'name'

    name = fields.Char(string='Tên Phòng Ban', required=True, translate=True)
    company_id = fields.Many2one('res.company', string='Công ty', default=lambda self: self.env.company)
    parent_id = fields.Many2one('hr.department', string='Phòng Ban Cha', ondelete='cascade')
    parent_path = fields.Char(index=True)
    color = fields.Integer(string='Màu')
    
    # Thông tin chung
    code = fields.Char(string='Mã Phòng Ban', required=True)
    description = fields.Text(string='Mô Tả')
    
    # Quản lý
    manager_id = fields.Many2one('simple.employee', string='Quản Lý Phòng', 
                                  domain="[('state', '=', 'active')]")
    
    # Thông tin tổ chức
    location = fields.Char(string='Vị Trí')
    phone = fields.Char(string='Điện Thoại')
    email = fields.Char(string='Email')
    
    # Ngân sách
    budget = fields.Float(string='Ngân Sách (VND)', default=0.0)
    budget_year = fields.Integer(string='Năm Ngân Sách', default=lambda self: datetime.now().year)
    budget_used = fields.Float(string='Ngân Sách Đã Sử Dụng', compute='_compute_budget_used')
    
    # Nhân sự
    employee_ids = fields.One2many('simple.employee', 'department_id', string='Nhân Viên')
    member_ids = fields.Many2many(
        'simple.employee',
        'hr_department_employee_rel',
        'department_id',
        'employee_id',
        string='Thành viên',
        help='Thành viên phòng ban để phục vụ tính năng chat OdooBot'
    )
    employee_count = fields.Integer(string='Số Lượng Nhân Viên', compute='_compute_employee_count')
    
    # Cấp độ
    level = fields.Selection([
        ('1', 'Cấp 1 - Ban Điều Hành'),
        ('2', 'Cấp 2 - Phòng Ban Chính'),
        ('3', 'Cấp 3 - Bộ Phận'),
        ('4', 'Cấp 4 - Nhóm'),
    ], string='Cấp Độ', default='2')
    
    # Trạng thái
    active = fields.Boolean(string='Hoạt Động', default=True)
    
    # Thời gian
    create_date = fields.Datetime(string='Ngày Tạo', readonly=True)
    write_date = fields.Datetime(string='Ngày Cập Nhật', readonly=True)
    
    @api.depends('employee_ids')
    def _compute_employee_count(self):
        for record in self:
            record.employee_count = len(record.employee_ids)
    
    @api.depends('employee_ids')
    def _compute_budget_used(self):
        for record in self:
            # Tính từ lương nhân viên
            total = 0
            for emp in record.employee_ids:
                contract = self.env['hr.contract.extended'].search([
                    ('employee_id', '=', emp.id),
                    ('state', '=', 'running')
                ], limit=1)
                if contract:
                    total += contract.wage
            record.budget_used = total
    
    def action_view_employees(self):
        """Xem danh sách nhân viên trong phòng"""
        return {
            'type': 'ir.actions.act_window',
            'name': f'Nhân Viên - {self.name}',
            'res_model': 'simple.employee',
            'view_mode': 'tree,form',
            'domain': [('department_id', '=', self.id)],
            'context': {'default_department_id': self.id},
        }
    
    @api.constrains('name', 'code')
    def _check_unique_code(self):
        for record in self:
            if self.search_count([('code', '=', record.code), ('id', '!=', record.id)]) > 0:
                raise models.ValidationError(f"Mã phòng ban '{record.code}' đã tồn tại!")
