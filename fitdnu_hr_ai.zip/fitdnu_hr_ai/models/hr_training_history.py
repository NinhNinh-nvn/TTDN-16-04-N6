# -*- coding: utf-8 -*-

from odoo import models, fields, api

class HrTrainingHistory(models.Model):
    _name = 'hr.training.history'
    _description = 'Lịch sử Đào tạo'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'start_date desc'

    employee_id = fields.Many2one('simple.employee', string='Nhân viên', required=True, tracking=True)
    
    course_name = fields.Char(string='Tên khóa học', required=True, tracking=True)
    training_type = fields.Selection([
        ('internal', 'Đào tạo nội bộ'),
        ('external', 'Đào tạo bên ngoài'),
        ('online', 'Đào tạo trực tuyến'),
        ('workshop', 'Hội thảo'),
        ('certification', 'Chứng chỉ'),
    ], string='Loại đào tạo', required=True, default='internal', tracking=True)
    
    start_date = fields.Date(string='Ngày bắt đầu', required=True)
    end_date = fields.Date(string='Ngày kết thúc', required=True)
    
    duration_hours = fields.Float(string='Thời lượng (giờ)', required=True)
    
    provider = fields.Char(string='Đơn vị đào tạo')
    instructor = fields.Char(string='Giảng viên')
    location = fields.Char(string='Địa điểm')
    
    cost = fields.Float(string='Chi phí đào tạo')
    
    result = fields.Selection([
        ('passed', 'Đạt'),
        ('failed', 'Không đạt'),
        ('excellent', 'Xuất sắc'),
        ('good', 'Khá'),
        ('average', 'Trung bình'),
    ], string='Kết quả', tracking=True)
    
    score = fields.Float(string='Điểm số')
    certificate = fields.Char(string='Chứng chỉ')
    certificate_date = fields.Date(string='Ngày cấp chứng chỉ')
    
    skills_gained = fields.Text(string='Kỹ năng đạt được')
    notes = fields.Text(string='Ghi chú')
    
    attachment_ids = fields.Many2many('ir.attachment', string='Tài liệu đính kèm')
    
    state = fields.Selection([
        ('planned', 'Kế hoạch'),
        ('ongoing', 'Đang thực hiện'),
        ('completed', 'Hoàn thành'),
        ('cancelled', 'Đã hủy'),
    ], string='Trạng thái', default='planned', tracking=True)
    
    @api.depends('start_date', 'end_date')
    def _compute_duration(self):
        for record in self:
            if record.start_date and record.end_date:
                delta = record.end_date - record.start_date
                record.duration_days = delta.days + 1
            else:
                record.duration_days = 0
    
    duration_days = fields.Integer(string='Số ngày', compute='_compute_duration', store=True)
