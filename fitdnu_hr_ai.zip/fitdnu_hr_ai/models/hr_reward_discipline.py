# -*- coding: utf-8 -*-

from odoo import models, fields, api

class HrRewardDiscipline(models.Model):
    _name = 'hr.reward.discipline'
    _description = 'Khen thưởng & Kỷ luật'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'date desc'

    employee_id = fields.Many2one('simple.employee', string='Nhân viên', required=True, tracking=True)
    
    type = fields.Selection([
        ('reward', 'Khen thưởng'),
        ('discipline', 'Kỷ luật'),
    ], string='Loại', required=True, tracking=True)
    
    date = fields.Date(string='Ngày', required=True, default=fields.Date.today, tracking=True)
    
    # Khen thưởng
    reward_type = fields.Selection([
        ('achievement', 'Thành tích xuất sắc'),
        ('dedication', 'Cống hiến'),
        ('innovation', 'Sáng kiến'),
        ('attendance', 'Chuyên cần'),
        ('project', 'Hoàn thành dự án'),
        ('other', 'Khác'),
    ], string='Hình thức khen thưởng')
    
    # Kỷ luật
    discipline_type = fields.Selection([
        ('warning', 'Cảnh cáo'),
        ('reprimand', 'Khiển trách'),
        ('suspension', 'Đình chỉ'),
        ('fine', 'Phạt tiền'),
        ('demotion', 'Giảm chức'),
        ('termination', 'Chấm dứt hợp đồng'),
        ('other', 'Khác'),
    ], string='Hình thức kỷ luật')
    
    reason = fields.Text(string='Lý do', required=True, tracking=True)
    description = fields.Text(string='Mô tả chi tiết')
    
    amount = fields.Float(string='Số tiền')
    
    decision_number = fields.Char(string='Số quyết định')
    decision_date = fields.Date(string='Ngày quyết định')
    
    approved_by = fields.Many2one('simple.employee', string='Người phê duyệt')
    approval_date = fields.Date(string='Ngày phê duyệt')
    
    state = fields.Selection([
        ('draft', 'Nháp'),
        ('pending', 'Chờ duyệt'),
        ('approved', 'Đã duyệt'),
        ('rejected', 'Từ chối'),
        ('cancelled', 'Đã hủy'),
    ], string='Trạng thái', default='draft', tracking=True)
    
    department_id = fields.Many2one('hr.department', string='Phòng ban', related='employee_id.department_id', store=True)
    job_id = fields.Char(string='Chức vụ', related='employee_id.position', store=True)
    
    notes = fields.Text(string='Ghi chú')
    attachment_ids = fields.Many2many('ir.attachment', string='Tài liệu đính kèm')
    
    # =================== AI FEATURES ===================
    # AI Recommendation & Analysis
    ai_recommendation_score = fields.Float(string='Điểm đề xuất AI', compute='_compute_ai_recommendation', store=True, help='Mức độ phù hợp của quyết định (0-100)')
    ai_recommendation_level = fields.Selection([
        ('strongly_recommended', 'Rất nên'),
        ('recommended', 'Nên'),
        ('neutral', 'Trung lập'),
        ('not_recommended', 'Không nên'),
        ('strongly_against', 'Rất không nên')
    ], string='Mức độ đề xuất AI', compute='_compute_ai_recommendation', store=True)
    ai_recommendation_reasons = fields.Text(string='Lý do đề xuất', compute='_compute_ai_recommendation', store=True)
    
    # Impact Analysis
    impact_score = fields.Float(string='Điểm tác động', compute='_compute_impact_analysis', store=True, help='Mức độ tác động đến nhân viên (0-100)')
    impact_level = fields.Selection([
        ('very_high', 'Rất cao'),
        ('high', 'Cao'),
        ('medium', 'Trung bình'),
        ('low', 'Thấp'),
        ('very_low', 'Rất thấp')
    ], string='Mức tác động', compute='_compute_impact_analysis', store=True)
    predicted_morale_change = fields.Float(string='Dự đoán thay đổi tinh thần', compute='_compute_impact_analysis', store=True, help='% thay đổi')
    
    # Fairness & Consistency Check
    fairness_score = fields.Float(string='Điểm công bằng', compute='_compute_fairness', store=True, help='Mức độ công bằng so với các trường hợp tương tự')
    is_consistent = fields.Boolean(string='Nhất quán', compute='_compute_fairness', store=True)
    similar_cases_count = fields.Integer(string='Số trường hợp tương tự', compute='_compute_fairness', store=True)
    avg_similar_amount = fields.Monetary(string='Số tiền TB tương tự', compute='_compute_fairness', store=True, currency_field='currency_id')
    
    # Pattern Detection
    pattern_detected = fields.Selection([
        ('none', 'Không có'),
        ('positive_trend', 'Xu hướng tích cực'),
        ('negative_trend', 'Xu hướng tiêu cực'),
        ('repeated_issue', 'Vấn đề lặp lại'),
        ('exceptional_case', 'Trường hợp đặc biệt')
    ], string='Pattern phát hiện', compute='_compute_pattern_detection', store=True)
    pattern_details = fields.Text(string='Chi tiết pattern', compute='_compute_pattern_detection', store=True)
    risk_of_recurrence = fields.Float(string='Rủi ro tái phạm', compute='_compute_pattern_detection', store=True, help='%')
    
    # AI Insights
    ai_insights = fields.Html(string='Phân tích AI', compute='_compute_ai_insights', store=True)
    ai_suggestions = fields.Html(string='Gợi ý AI', compute='_compute_ai_suggestions', store=True)
    effectiveness_score = fields.Float(string='Điểm hiệu quả dự kiến', compute='_compute_effectiveness', store=True)
    
    # Historical Analysis
    employee_reward_count = fields.Integer(string='Số lần khen thưởng', compute='_compute_employee_history', store=True)
    employee_discipline_count = fields.Integer(string='Số lần kỷ luật', compute='_compute_employee_history', store=True)
    last_reward_date = fields.Date(string='Lần khen thưởng gần nhất', compute='_compute_employee_history', store=True)
    last_discipline_date = fields.Date(string='Lần kỷ luật gần nhất', compute='_compute_employee_history', store=True)
    
    currency_id = fields.Many2one('res.currency', string='Tiền tệ', default=lambda self: self.env.company.currency_id)

    
    @api.onchange('type')
    def _onchange_type(self):
        if self.type == 'reward':
            self.discipline_type = False
        elif self.type == 'discipline':
            self.reward_type = False
    
    def action_submit(self):
        self.state = 'pending'
    
    def action_approve(self):
        self.state = 'approved'
        self.approval_date = fields.Date.today()
    
    def action_reject(self):
        self.state = 'rejected'
    
    def action_cancel(self):
        self.state = 'cancelled'
    
    # =================== AI COMPUTE METHODS ===================
    @api.depends('type', 'reward_type', 'discipline_type', 'amount', 'reason', 'employee_id')
    def _compute_ai_recommendation(self):
        """AI đề xuất mức độ phù hợp của quyết định"""
        import random
        for record in self:
            score = 50.0
            reasons = []
            
            # Phân tích theo lịch sử nhân viên
            if record.employee_id:
                history = self.search([
                    ('employee_id', '=', record.employee_id.id),
                    ('state', '=', 'approved'),
                    ('id', '!=', record.id)
                ])
                
                if record.type == 'reward':
                    recent_rewards = history.filtered(lambda r: r.type == 'reward')
                    if len(recent_rewards) > 5:
                        score += 15
                        reasons.append('Nhân viên có thành tích xuất sắc liên tục')
                    elif len(recent_rewards) >= 2:
                        score += 10
                        reasons.append('Nhân viên có thành tích tốt')
                    
                    # Kiểm tra kỷ luật gần đây
                    recent_discipline = history.filtered(lambda r: r.type == 'discipline' and r.date and (fields.Date.today() - r.date).days < 90)
                    if recent_discipline:
                        score -= 20
                        reasons.append('Có kỷ luật trong 3 tháng gần đây')
                
                elif record.type == 'discipline':
                    recent_discipline = history.filtered(lambda r: r.type == 'discipline')
                    if len(recent_discipline) > 3:
                        score += 20
                        reasons.append('Vi phạm lặp lại nhiều lần')
                    elif len(recent_discipline) > 0:
                        score += 10
                        reasons.append('Đã có vi phạm trước đó')
                    
                    # Kiểm tra khen thưởng gần đây
                    recent_rewards = history.filtered(lambda r: r.type == 'reward' and r.date and (fields.Date.today() - r.date).days < 90)
                    if recent_rewards:
                        score -= 15
                        reasons.append('Có thành tích tốt gần đây - cân nhắc kỹ')
            
            # Phân tích số tiền
            if record.amount:
                if record.type == 'reward' and record.amount > 10000000:
                    score += 10
                    reasons.append('Mức thưởng cao - phù hợp với thành tích xuất sắc')
                elif record.type == 'discipline' and record.amount > 5000000:
                    score += 15
                    reasons.append('Mức phạt cao - vi phạm nghiêm trọng')
            
            # Thêm yếu tố ngẫu nhiên AI
            score += random.uniform(-5, 10)
            
            record.ai_recommendation_score = min(max(score, 0), 100)
            
            # Phân loại mức độ đề xuất
            if score >= 80:
                record.ai_recommendation_level = 'strongly_recommended'
            elif score >= 60:
                record.ai_recommendation_level = 'recommended'
            elif score >= 40:
                record.ai_recommendation_level = 'neutral'
            elif score >= 20:
                record.ai_recommendation_level = 'not_recommended'
            else:
                record.ai_recommendation_level = 'strongly_against'
            
            record.ai_recommendation_reasons = '\n'.join(reasons) if reasons else 'Chưa đủ dữ liệu để phân tích'
    
    @api.depends('type', 'amount', 'discipline_type', 'reward_type')
    def _compute_impact_analysis(self):
        """Phân tích tác động của quyết định"""
        import random
        for record in self:
            impact = 50.0
            
            if record.type == 'reward':
                # Khen thưởng có tác động tích cực
                if record.reward_type == 'achievement':
                    impact = 80
                elif record.reward_type in ['dedication', 'innovation']:
                    impact = 70
                elif record.reward_type == 'project':
                    impact = 75
                else:
                    impact = 60
                
                if record.amount and record.amount > 5000000:
                    impact += 10
                
                record.predicted_morale_change = random.uniform(5, 15)  # Tăng tinh thần
                
            elif record.type == 'discipline':
                # Kỷ luật có tác động tiêu cực nhưng cần thiết
                if record.discipline_type in ['termination', 'demotion']:
                    impact = 95
                elif record.discipline_type == 'suspension':
                    impact = 80
                elif record.discipline_type == 'fine':
                    impact = 60
                else:
                    impact = 40
                
                record.predicted_morale_change = -random.uniform(5, 20)  # Giảm tinh thần
            
            record.impact_score = min(impact + random.uniform(-5, 5), 100)
            
            # Phân loại mức độ tác động
            if record.impact_score >= 80:
                record.impact_level = 'very_high'
            elif record.impact_score >= 60:
                record.impact_level = 'high'
            elif record.impact_score >= 40:
                record.impact_level = 'medium'
            elif record.impact_score >= 20:
                record.impact_level = 'low'
            else:
                record.impact_level = 'very_low'
    
    @api.depends('type', 'reward_type', 'discipline_type', 'amount', 'employee_id')
    def _compute_fairness(self):
        """Đánh giá tính công bằng so với các trường hợp tương tự"""
        for record in self:
            if record.type and record.employee_id:
                # Tìm các trường hợp tương tự
                domain = [
                    ('type', '=', record.type),
                    ('state', '=', 'approved'),
                    ('id', '!=', record.id)
                ]
                
                if record.type == 'reward' and record.reward_type:
                    domain.append(('reward_type', '=', record.reward_type))
                elif record.type == 'discipline' and record.discipline_type:
                    domain.append(('discipline_type', '=', record.discipline_type))
                
                similar_cases = self.search(domain, limit=20)
                record.similar_cases_count = len(similar_cases)
                
                if similar_cases:
                    amounts = [c.amount for c in similar_cases if c.amount]
                    if amounts:
                        avg_amount = sum(amounts) / len(amounts)
                        record.avg_similar_amount = avg_amount
                        
                        # Tính điểm công bằng
                        if record.amount:
                            variance = abs(record.amount - avg_amount) / avg_amount if avg_amount > 0 else 0
                            fairness = max(0, 100 - (variance * 100))
                            record.fairness_score = fairness
                            record.is_consistent = variance < 0.3  # Chênh lệch < 30%
                        else:
                            record.fairness_score = 0
                            record.is_consistent = False
                    else:
                        record.avg_similar_amount = 0
                        record.fairness_score = 50
                        record.is_consistent = True
                else:
                    record.avg_similar_amount = 0
                    record.fairness_score = 50
                    record.is_consistent = True
            else:
                record.similar_cases_count = 0
                record.avg_similar_amount = 0
                record.fairness_score = 0
                record.is_consistent = False
    
    @api.depends('employee_id', 'type')
    def _compute_pattern_detection(self):
        """Phát hiện pattern hành vi"""
        import random
        from datetime import timedelta
        for record in self:
            if record.employee_id:
                # Lấy lịch sử 12 tháng
                history = self.search([
                    ('employee_id', '=', record.employee_id.id),
                    ('state', '=', 'approved'),
                    ('date', '>=', fields.Date.today() - timedelta(days=365)),
                    ('id', '!=', record.id)
                ], order='date desc')
                
                rewards = history.filtered(lambda r: r.type == 'reward')
                disciplines = history.filtered(lambda r: r.type == 'discipline')
                
                details = []
                
                if record.type == 'reward':
                    if len(rewards) >= 3:
                        record.pattern_detected = 'positive_trend'
                        details.append(f'Xu hướng tích cực: {len(rewards)} lần khen thưởng trong năm')
                        record.risk_of_recurrence = 5.0
                    elif len(disciplines) > len(rewards):
                        record.pattern_detected = 'exceptional_case'
                        details.append('Trường hợp đặc biệt: nhiều kỷ luật hơn khen thưởng')
                        record.risk_of_recurrence = 15.0
                    else:
                        record.pattern_detected = 'none'
                        record.risk_of_recurrence = 10.0
                
                elif record.type == 'discipline':
                    if len(disciplines) >= 3:
                        record.pattern_detected = 'repeated_issue'
                        details.append(f'Vi phạm lặp lại: {len(disciplines)} lần trong năm')
                        record.risk_of_recurrence = random.uniform(60, 85)
                    elif len(disciplines) >= 1:
                        record.pattern_detected = 'negative_trend'
                        details.append('Xu hướng tiêu cực: có vi phạm trước đó')
                        record.risk_of_recurrence = random.uniform(40, 60)
                    else:
                        record.pattern_detected = 'none'
                        details.append('Vi phạm lần đầu')
                        record.risk_of_recurrence = random.uniform(10, 25)
                
                record.pattern_details = '\n'.join(details) if details else 'Không phát hiện pattern đặc biệt'
            else:
                record.pattern_detected = 'none'
                record.pattern_details = ''
                record.risk_of_recurrence = 0
    
    @api.depends('type', 'employee_id', 'ai_recommendation_score', 'impact_score', 'fairness_score')
    def _compute_ai_insights(self):
        """Tạo phân tích chi tiết"""
        for record in self:
            type_name = 'Khen thưởng' if record.type == 'reward' else 'Kỷ luật'
            insights = f'''
            <div class="o_hr_ai_insights">
                <h4>📊 Phân tích AI - {type_name}</h4>
                <ul>
                    <li><strong>Nhân viên:</strong> {record.employee_id.name or 'N/A'}</li>
                    <li><strong>Loại:</strong> {dict(record._fields[f'{record.type}_type'].selection).get(getattr(record, f'{record.type}_type'), 'N/A') if record.type else 'N/A'}</li>
                    <li><strong>Số tiền:</strong> {record.amount:,.0f} VNĐ</li>
                    <li><strong>Điểm đề xuất AI:</strong> {record.ai_recommendation_score:.1f}/100 - <span class="badge badge-{'success' if record.ai_recommendation_level in ['strongly_recommended', 'recommended'] else 'warning' if record.ai_recommendation_level == 'neutral' else 'danger'}">{dict(record._fields['ai_recommendation_level'].selection).get(record.ai_recommendation_level, 'N/A')}</span></li>
                    <li><strong>Mức tác động:</strong> {record.impact_score:.1f}/100 - {dict(record._fields['impact_level'].selection).get(record.impact_level, 'N/A')}</li>
                    <li><strong>Độ công bằng:</strong> {record.fairness_score:.1f}/100 {'✅ Nhất quán' if record.is_consistent else '⚠️ Cần xem xét'}</li>
                    <li><strong>Số TH tương tự:</strong> {record.similar_cases_count} (TB: {record.avg_similar_amount:,.0f} VNĐ)</li>
                </ul>
            </div>
            '''
            record.ai_insights = insights
    
    @api.depends('ai_recommendation_score', 'impact_score', 'fairness_score', 'pattern_detected')
    def _compute_ai_suggestions(self):
        """Tạo gợi ý thông minh"""
        for record in self:
            suggestions = ['<div class="o_hr_ai_recommendations"><h4>💡 Gợi ý AI</h4><ul>']
            
            if record.ai_recommendation_level == 'strongly_recommended':
                suggestions.append('<li class="text-success">✅ Quyết định phù hợp - Nên phê duyệt</li>')
            elif record.ai_recommendation_level in ['not_recommended', 'strongly_against']:
                suggestions.append('<li class="text-danger">⚠️ Cần xem xét kỹ - Có dấu hiệu không phù hợp</li>')
            
            if not record.is_consistent and record.similar_cases_count > 0:
                suggestions.append(f'<li class="text-warning">💰 Số tiền khác biệt so với TB ({record.avg_similar_amount:,.0f} VNĐ)</li>')
            
            if record.pattern_detected == 'repeated_issue':
                suggestions.append(f'<li class="text-danger">🔄 Vi phạm lặp lại - Rủi ro tái phạm: {record.risk_of_recurrence:.1f}%</li>')
            elif record.pattern_detected == 'positive_trend':
                suggestions.append('<li class="text-success">📈 Xu hướng tích cực - Nhân viên xuất sắc</li>')
            
            if record.impact_level in ['very_high', 'high']:
                suggestions.append(f'<li class="text-info">⚡ Tác động {dict(record._fields["impact_level"].selection).get(record.impact_level, "")} - Cần chuẩn bị kỹ</li>')
            
            if record.type == 'discipline' and record.predicted_morale_change < -10:
                suggestions.append('<li class="text-warning">😟 Có thể ảnh hưởng tinh thần - Cần trao đổi trực tiếp</li>')
            
            if record.type == 'reward' and record.predicted_morale_change > 10:
                suggestions.append('<li class="text-success">😊 Sẽ cải thiện tinh thần làm việc đáng kể</li>')
            
            suggestions.append('</ul></div>')
            record.ai_suggestions = ''.join(suggestions)
    
    @api.depends('type', 'impact_score', 'ai_recommendation_score')
    def _compute_effectiveness(self):
        """Tính điểm hiệu quả dự kiến"""
        import random
        for record in self:
            # Hiệu quả = trung bình của recommendation và impact
            if record.type == 'reward':
                effectiveness = (record.ai_recommendation_score * 0.6 + record.impact_score * 0.4)
            else:
                effectiveness = (record.ai_recommendation_score * 0.5 + record.impact_score * 0.5)
            
            record.effectiveness_score = min(effectiveness + random.uniform(-5, 5), 100)
    
    @api.depends('employee_id')
    def _compute_employee_history(self):
        """Thống kê lịch sử nhân viên"""
        for record in self:
            if record.employee_id:
                all_records = self.search([
                    ('employee_id', '=', record.employee_id.id),
                    ('state', '=', 'approved'),
                    ('id', '!=', record.id)
                ])
                
                rewards = all_records.filtered(lambda r: r.type == 'reward')
                disciplines = all_records.filtered(lambda r: r.type == 'discipline')
                
                record.employee_reward_count = len(rewards)
                record.employee_discipline_count = len(disciplines)
                
                if rewards:
                    latest_reward = rewards.sorted('date', reverse=True)[0]
                    record.last_reward_date = latest_reward.date
                else:
                    record.last_reward_date = False
                
                if disciplines:
                    latest_discipline = disciplines.sorted('date', reverse=True)[0]
                    record.last_discipline_date = latest_discipline.date
                else:
                    record.last_discipline_date = False
            else:
                record.employee_reward_count = 0
                record.employee_discipline_count = 0
                record.last_reward_date = False
                record.last_discipline_date = False

