# -*- coding: utf-8 -*-
from odoo import models, fields, api
from datetime import datetime, time
import json
import random

class SimpleAttendance(models.Model):
    _name = 'simple.attendance'
    _description = 'Chấm công (AI)'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'attendance_date desc, check_in_time desc'
    _sql_constraints = [
        ('unique_employee_date_checkin', 
         'UNIQUE(employee_id, attendance_date, check_in_time)',
         'Nhân viên đã chấm công vào thời gian này rồi! (Duplicate check)')
    ]

    employee_id = fields.Many2one('simple.employee', 'Nhân viên', required=True, tracking=True)
    attendance_date = fields.Date('Ngày chấm công', required=True, default=fields.Date.today, tracking=True)
    check_in_time = fields.Float('Giờ vào (HH.MM)', help='Ví dụ: 8.5 = 8:30')
    check_out_time = fields.Float('Giờ ra (HH.MM)')
    
    # AI Features - Face Recognition
    face_recognition_score = fields.Float('Độ chính xác nhận diện (%)', default=0.0, 
                                          help='AI Face Recognition confidence score')
    face_image = fields.Binary('Ảnh chấm công', attachment=True)
    face_verified = fields.Boolean('Đã xác thực khuôn mặt', default=False)
    face_capture_method = fields.Selection([
        ('webcam', 'Webcam'),
        ('mobile', 'Mobile Camera'),
        ('upload', 'Upload File'),
        ('ai_camera', 'AI Camera Device'),
    ], 'Phương thức chụp', default='webcam')
    face_match_reference = fields.Binary('Ảnh tham chiếu', related='employee_id.image')
    face_comparison_data = fields.Text('Dữ liệu so sánh AI', help='JSON data from face comparison')
    
    # AI Features - Location Tracking
    gps_latitude = fields.Float('Vĩ độ GPS', digits=(10, 6))
    gps_longitude = fields.Float('Kinh độ GPS', digits=(10, 6))
    location_verified = fields.Boolean('Vị trí hợp lệ', compute='_compute_location_verified', store=True)
    distance_from_office = fields.Float('Khoảng cách (km)', compute='_compute_distance', store=True)
    
    # AI Features - Pattern Analysis
    attendance_pattern_score = fields.Float('Điểm pattern (%)', compute='_compute_pattern_score', store=True,
                                           help='AI analysis of attendance consistency')
    is_unusual_time = fields.Boolean('Giờ bất thường', compute='_compute_unusual_time', store=True)
    
    # AI Features - Anomaly Detection
    anomaly_detected = fields.Boolean('Phát hiện bất thường', default=False)
    anomaly_type = fields.Selection([
        ('duplicate', 'Trùng lặp'),
        ('impossible_time', 'Thời gian không hợp lý'),
        ('location_mismatch', 'Vị trí không khớp'),
        ('face_mismatch', 'Khuôn mặt không khớp'),
        ('low_face_score', 'Điểm khuôn mặt thấp'),
        ('missing_checkout', 'Thiếu giờ ra'),
        ('proxy_attendance', 'Chấm công hộ (gian lận)'),
        ('time_manipulation', 'Thao túng thời gian'),
        ('fake_gps', 'GPS giả mạo'),
    ], 'Loại bất thường')
    anomaly_details = fields.Text('Chi tiết bất thường')
    fraud_risk_score = fields.Float('Điểm rủi ro gian lận (%)', compute='_compute_fraud_risk', store=True,
                                   help='AI-based fraud detection score')
    requires_investigation = fields.Boolean('Cần điều tra', compute='_compute_requires_investigation', store=True)
    
    # AI Predictions
    predicted_checkout = fields.Float('Dự đoán giờ ra', compute='_compute_predicted_checkout')
    predicted_overtime = fields.Float('Dự đoán OT (giờ)', compute='_compute_predicted_overtime')
    
    # Computed fields (AI Detection)
    is_late = fields.Boolean('Đi muộn?', compute='_compute_is_late', store=True)
    late_minutes = fields.Integer('Muộn (phút)', compute='_compute_late_minutes', store=True)
    working_hours = fields.Float('Giờ làm', compute='_compute_working_hours', store=True)
    overtime_hours = fields.Float('Giờ OT', compute='_compute_overtime', store=True)
    is_weekend = fields.Boolean('Cuối tuần', compute='_compute_is_weekend', store=True)
    is_missing_checkout = fields.Boolean('Thiếu giờ ra', compute='_compute_is_missing_checkout', store=True)
    
    # Late reason & approval
    late_reason = fields.Text('Lý do đi muộn')
    late_reason_status = fields.Selection([
        ('pending', 'Chờ duyệt'),
        ('approved', 'Đã duyệt'),
        ('rejected', 'Từ chối'),
    ], 'Trạng thái giải trình', default='pending')
    late_approved_by = fields.Many2one('res.users', 'Người phê duyệt')
    late_approved_date = fields.Datetime('Ngày phê duyệt')
    
    # Approval Workflow (for overtime, forgot attendance)
    approval_state = fields.Selection([
        ('draft', 'Nháp'),
        ('submitted', 'Chờ duyệt'),
        ('approved', 'Đã duyệt'),
        ('rejected', 'Từ chối'),
    ], 'Trạng thái phê duyệt', default='draft', tracking=True)
    approved_by = fields.Many2one('res.users', 'Người duyệt')
    approved_date = fields.Datetime('Ngày duyệt')
    approval_notes = fields.Text('Ghi chú phê duyệt')
    
    # Forgot attendance handling
    is_manual_entry = fields.Boolean('Nhập tay (quên chấm)', default=False)
    manual_entry_reason = fields.Text('Lý do nhập tay')
    manual_entry_by = fields.Many2one('res.users', 'Người nhập', default=lambda self: self.env.user)
    manual_entry_date = fields.Datetime('Thời gian nhập', default=fields.Datetime.now)
    has_supporting_document = fields.Boolean('Có chứng từ')
    supporting_document = fields.Binary('Chứng từ đính kèm', attachment=True)
    
    # Overtime approval
    overtime_requested = fields.Float('Tăng ca đề xuất (giờ)')
    overtime_approved = fields.Float('Tăng ca được duyệt (giờ)')
    overtime_reason = fields.Text('Lý do tăng ca')
    overtime_approval_state = fields.Selection([
        ('none', 'Không có'),
        ('pending', 'Chờ duyệt'),
        ('approved', 'Đã duyệt'),
        ('rejected', 'Từ chối'),
    ], 'Trạng thái duyệt OT', default='none')
    
    state = fields.Selection([
        ('present', 'Có mặt'),
        ('absent', 'Vắng'),
        ('late', 'Đi muộn'),
        ('early_leave', 'Về sớm'),
    ], 'Trạng thái', compute='_compute_state', store=True)
    
    # AI Insights
    ai_insights = fields.Text('AI Phân tích', compute='_compute_ai_insights')
    confidence_score = fields.Float('Độ tin cậy AI (%)', compute='_compute_confidence_score', store=True)
    
    # Late Fine Calculation
    late_fine_amount = fields.Float('Tiền phạt đi muộn', compute='_compute_late_fine', store=True, help='Tính theo bậc thang')
    
    # GPS Config (can be overridden per company)
    office_latitude = fields.Float('Office Latitude', default=21.0285, help='Tọa độ văn phòng')
    office_longitude = fields.Float('Office Longitude', default=105.8542, help='Tọa độ văn phòng')
    allowed_radius_km = fields.Float('Bán kính cho phép (km)', default=0.5, help='Khoảng cách tối đa từ văn phòng')

    @api.depends('check_in_time', 'employee_id.check_in_time', 'employee_id.late_threshold_minutes')
    def _compute_is_late(self):
        for record in self:
            if record.check_in_time and record.employee_id:
                threshold_minutes = record.employee_id.late_threshold_minutes or 5
                threshold_hours = threshold_minutes / 60.0
                expected_time = record.employee_id.check_in_time + threshold_hours
                record.is_late = record.check_in_time > expected_time
            else:
                record.is_late = False

    @api.depends('check_in_time', 'employee_id.check_in_time', 'employee_id.late_threshold_minutes')
    def _compute_late_minutes(self):
        for record in self:
            if record.check_in_time and record.employee_id:
                threshold_minutes = record.employee_id.late_threshold_minutes or 5
                threshold_hours = threshold_minutes / 60.0
                expected_time = record.employee_id.check_in_time + threshold_hours
                late_hours = max(0, record.check_in_time - expected_time)
                record.late_minutes = int(late_hours * 60)
            else:
                record.late_minutes = 0

    @api.depends('check_in_time', 'check_out_time')
    def _compute_working_hours(self):
        for record in self:
            if record.check_in_time and record.check_out_time:
                record.working_hours = max(0, record.check_out_time - record.check_in_time)
            else:
                record.working_hours = 0.0

    @api.depends('attendance_date')
    def _compute_is_weekend(self):
        for record in self:
            if record.attendance_date:
                day = fields.Date.to_date(record.attendance_date).weekday()
                record.is_weekend = day >= 5  # 5=Saturday, 6=Sunday
            else:
                record.is_weekend = False

    @api.depends('check_in_time', 'check_out_time')
    def _compute_is_missing_checkout(self):
        for record in self:
            record.is_missing_checkout = bool(record.check_in_time and not record.check_out_time)
    
    @api.depends('late_minutes', 'is_late')
    def _compute_late_fine(self):
        """Tính phạt đi muộn theo bậc thang:
        - 5-15 phút: 50,000đ
        - 16-30 phút: 100,000đ
        - 31-60 phút: 200,000đ
        - >60 phút: 500,000đ
        """
        for record in self:
            if not record.is_late or record.late_minutes == 0:
                record.late_fine_amount = 0
            elif record.late_minutes <= 15:
                record.late_fine_amount = 50000
            elif record.late_minutes <= 30:
                record.late_fine_amount = 100000
            elif record.late_minutes <= 60:
                record.late_fine_amount = 200000
            else:
                record.late_fine_amount = 500000

    @api.depends('working_hours', 'employee_id.work_hours_per_day')
    def _compute_overtime(self):
        for record in self:
            if record.working_hours and record.employee_id:
                standard_hours = record.employee_id.work_hours_per_day or 8.0
                record.overtime_hours = max(0, record.working_hours - standard_hours)
            else:
                record.overtime_hours = 0.0

    @api.depends('is_late', 'check_in_time', 'check_out_time', 'employee_id.check_out_time')
    def _compute_state(self):
        for record in self:
            if not record.check_in_time:
                record.state = 'absent'
            elif record.is_late:
                record.state = 'late'
            elif record.check_out_time and record.employee_id.check_out_time:
                # Check early leave
                if record.check_out_time < record.employee_id.check_out_time - 0.5:  # 30 min before
                    record.state = 'early_leave'
                else:
                    record.state = 'present'
            else:
                record.state = 'present'
    
    @api.depends('gps_latitude', 'gps_longitude', 'office_latitude', 'office_longitude', 'allowed_radius_km')
    def _compute_location_verified(self):
        """AI: Verify GPS location is within office radius (configurable)"""
        for record in self:
            if record.gps_latitude and record.gps_longitude:
                distance = record._calculate_distance(
                    record.gps_latitude, record.gps_longitude,
                    record.office_latitude, record.office_longitude
                )
                record.location_verified = distance <= record.allowed_radius_km
            else:
                record.location_verified = False
    
    @api.depends('gps_latitude', 'gps_longitude', 'office_latitude', 'office_longitude')
    def _compute_distance(self):
        """AI: Calculate distance from office (using config)"""
        for record in self:
            if record.gps_latitude and record.gps_longitude:
                record.distance_from_office = record._calculate_distance(
                    record.gps_latitude, record.gps_longitude,
                    record.office_latitude, record.office_longitude
                )
            else:
                record.distance_from_office = 0.0
    
    def _calculate_distance(self, lat1, lon1, lat2, lon2):
        """Calculate distance using Haversine formula"""
        from math import radians, sin, cos, sqrt, atan2
        
        R = 6371  # Earth radius in km
        
        lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])
        dlat = lat2 - lat1
        dlon = lon2 - lon1
        
        a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
        c = 2 * atan2(sqrt(a), sqrt(1-a))
        distance = R * c
        
        return distance
    
    @api.depends('employee_id', 'attendance_date')
    def _compute_pattern_score(self):
        """AI: Analyze attendance pattern consistency"""
        for record in self:
            if not record.employee_id or not record.attendance_date:
                record.attendance_pattern_score = 0.0
                continue
            
            # Get last 30 days attendance
            past_attendances = self.search([
                ('employee_id', '=', record.employee_id.id),
                ('attendance_date', '<', record.attendance_date),
                ('attendance_date', '>=', fields.Date.subtract(record.attendance_date, days=30))
            ], limit=30)
            
            if not past_attendances:
                record.attendance_pattern_score = 100.0
                continue
            
            # Calculate consistency metrics
            on_time_count = len(past_attendances.filtered(lambda x: x.state == 'present'))
            total_count = len(past_attendances)
            
            score = (on_time_count / total_count * 100) if total_count > 0 else 100.0
            record.attendance_pattern_score = round(score, 2)
    
    @api.depends('check_in_time', 'employee_id')
    def _compute_unusual_time(self):
        """AI: Detect unusual check-in times"""
        for record in self:
            if not record.check_in_time or not record.employee_id:
                record.is_unusual_time = False
                continue
            
            expected_time = record.employee_id.check_in_time
            time_diff = abs(record.check_in_time - expected_time)
            
            # Flag as unusual if more than 2 hours difference
            record.is_unusual_time = time_diff > 2.0
    
    @api.depends('check_in_time', 'employee_id')
    def _compute_predicted_checkout(self):
        """AI: Predict checkout time based on historical data"""
        for record in self:
            if not record.check_in_time or not record.employee_id:
                record.predicted_checkout = 0.0
                continue
            
            # Get average working hours from past 30 days
            past_attendances = self.search([
                ('employee_id', '=', record.employee_id.id),
                ('attendance_date', '<', record.attendance_date),
                ('working_hours', '>', 0)
            ], limit=30, order='attendance_date desc')
            
            if past_attendances:
                avg_working_hours = sum(past_attendances.mapped('working_hours')) / len(past_attendances)
                record.predicted_checkout = record.check_in_time + avg_working_hours
            else:
                # Default: standard working hours
                record.predicted_checkout = record.check_in_time + (record.employee_id.work_hours_per_day or 8.0)
    
    @api.depends('predicted_checkout', 'employee_id')
    def _compute_predicted_overtime(self):
        """AI: Predict overtime hours"""
        for record in self:
            if not record.predicted_checkout or not record.employee_id:
                record.predicted_overtime = 0.0
                continue
            
            expected_checkout = record.employee_id.check_out_time or 17.0
            predicted_ot = max(0, record.predicted_checkout - expected_checkout)
            record.predicted_overtime = round(predicted_ot, 2)
    
    @api.depends('face_recognition_score', 'location_verified', 'anomaly_detected', 'attendance_pattern_score')
    def _compute_confidence_score(self):
        """AI: Overall confidence score for attendance validity"""
        for record in self:
            score = 0.0
            weights = 0
            
            # Face recognition weight: 40%
            if record.face_recognition_score > 0:
                score += record.face_recognition_score * 0.4
                weights += 0.4
            
            # Location verification weight: 30%
            if record.gps_latitude:
                location_score = 100.0 if record.location_verified else 0.0
                score += location_score * 0.3
                weights += 0.3
            
            # Pattern consistency weight: 20%
            if record.attendance_pattern_score > 0:
                score += record.attendance_pattern_score * 0.2
                weights += 0.2
            
            # No anomaly weight: 10%
            anomaly_score = 0.0 if record.anomaly_detected else 100.0
            score += anomaly_score * 0.1
            weights += 0.1
            
            record.confidence_score = round(score / weights if weights > 0 else 0.0, 2)
    
    @api.depends('confidence_score', 'state', 'anomaly_detected', 'attendance_pattern_score')
    def _compute_ai_insights(self):
        """AI: Generate insights and recommendations"""
        for record in self:
            insights = []
            
            if record.confidence_score >= 90:
                insights.append("✓ Độ tin cậy cao - Chấm công hợp lệ")
            elif record.confidence_score >= 70:
                insights.append("⚠ Độ tin cậy trung bình - Cần xem xét")
            else:
                insights.append("✗ Độ tin cậy thấp - Cần xác minh")
            
            if record.anomaly_detected:
                insights.append(f"⚠ Phát hiện bất thường: {record.anomaly_type}")
            
            if record.attendance_pattern_score < 70:
                insights.append("📊 Pattern không ổn định - Cần theo dõi")
            elif record.attendance_pattern_score >= 90:
                insights.append("📊 Pattern xuất sắc - Nhân viên đều đặn")
            
            if record.is_unusual_time:
                insights.append("⏰ Giờ chấm công bất thường")
            
            if record.predicted_overtime > 0:
                insights.append(f"📈 Dự đoán OT: {record.predicted_overtime:.1f} giờ")
            
            if not record.location_verified and record.gps_latitude:
                insights.append(f"📍 Vị trí xa văn phòng {record.distance_from_office:.2f}km")
            
            record.ai_insights = "\n".join(insights) if insights else "Không có insights"
    
    def action_verify_face(self):
        """Simulate AI face verification"""
        for record in self:
            # Simulate face recognition (in production, call actual AI service)
            record.face_recognition_score = random.uniform(85.0, 99.5)
            record.face_verified = record.face_recognition_score >= 85.0
            
            if record.face_verified:
                record.message_post(body="✓ AI xác thực khuôn mặt thành công (%.2f%%)" % record.face_recognition_score)
            else:
                record.message_post(body="✗ AI xác thực khuôn mặt thất bại (%.2f%%)" % record.face_recognition_score)
    
    def action_detect_anomalies(self):
        """AI: Detect anomalies in attendance data"""
        for record in self:
            # Check for duplicate entries
            duplicates = self.search([
                ('employee_id', '=', record.employee_id.id),
                ('attendance_date', '=', record.attendance_date),
                ('id', '!=', record.id)
            ])
            
            if duplicates:
                record.anomaly_detected = True
                record.anomaly_type = 'duplicate'
                record.anomaly_details = f"Phát hiện {len(duplicates)} bản ghi trùng lặp"
                continue
            
            # Check impossible times
            if record.check_in_time and record.check_out_time:
                if record.check_out_time <= record.check_in_time:
                    record.anomaly_detected = True
                    record.anomaly_type = 'impossible_time'
                    record.anomaly_details = "Giờ ra nhỏ hơn giờ vào"
                    continue
            
            # Check location mismatch
            if record.gps_latitude and not record.location_verified:
                record.anomaly_detected = True
                record.anomaly_type = 'location_mismatch'
                record.anomaly_details = f"Vị trí xa văn phòng {record.distance_from_office:.2f}km"
                continue

            # Check low face score when face was captured
            if record.face_recognition_score and record.face_recognition_score < 70:
                record.anomaly_detected = True
                record.anomaly_type = 'low_face_score'
                record.anomaly_details = "Điểm nhận diện khuôn mặt thấp (<70%)"
                continue

            # Missing checkout after check-in
            if record.is_missing_checkout:
                record.anomaly_detected = True
                record.anomaly_type = 'missing_checkout'
                record.anomaly_details = "Có giờ vào nhưng thiếu giờ ra"
                continue
            
            record.anomaly_detected = False
            record.anomaly_type = False
            record.anomaly_details = False
    
    @api.depends('face_recognition_score', 'location_verified', 'is_unusual_time', 'anomaly_detected', 'distance_from_office')
    def _compute_fraud_risk(self):
        """AI: Calculate fraud risk score - Enhanced with proxy detection"""
        for record in self:
            risk_score = 0.0
            
            # Low/missing face recognition score
            if record.face_image and (not record.face_recognition_score or record.face_recognition_score < 70):
                risk_score += 30
            elif record.face_recognition_score and record.face_recognition_score < 85:
                risk_score += 15
            
            # Location issues
            if record.gps_latitude and not record.location_verified:
                # Gradual risk based on distance
                if record.distance_from_office > 5:  # >5km
                    risk_score += 40
                elif record.distance_from_office > 2:  # >2km
                    risk_score += 25
                elif record.distance_from_office > record.allowed_radius_km:
                    risk_score += 15
            
            # No GPS data when required
            if not record.gps_latitude and not record.is_manual_entry:
                risk_score += 20
            
            # Unusual time patterns
            if record.is_unusual_time:
                risk_score += 15
            
            # Check proxy attendance patterns (same device/IP in short time)
            # Only check if record is already saved (has real ID)
            if record.check_in_time and record.id and isinstance(record.id, int):
                # Find other attendances within 5 minutes
                same_time_records = self.search([
                    ('id', '!=', record.id),
                    ('attendance_date', '=', record.attendance_date),
                    ('check_in_time', '>=', record.check_in_time - 0.1),  # ±6 mins
                    ('check_in_time', '<=', record.check_in_time + 0.1),
                ])
                if len(same_time_records) >= 2:
                    risk_score += 25
                    if not record.anomaly_detected:
                        record.anomaly_detected = True
                        record.anomaly_type = 'proxy_attendance'
                        record.anomaly_details = f'Phát hiện {len(same_time_records)} nhân viên khác chấm công cùng lúc (nghi chấm hộ)'
            
            # Already flagged anomaly
            if record.anomaly_detected:
                risk_score += 20
            
            # Manual entry without document
            if record.is_manual_entry and not record.has_supporting_document:
                risk_score += 10
            
            record.fraud_risk_score = min(risk_score, 100.0)
    
    @api.depends('fraud_risk_score', 'anomaly_detected')
    def _compute_requires_investigation(self):
        """Determine if attendance requires investigation"""
        for record in self:
            record.requires_investigation = (
                record.fraud_risk_score >= 50 or 
                record.anomaly_type in ['proxy_attendance', 'fake_gps', 'time_manipulation']
            )
    
    def action_webcam_capture(self):
        """Open webcam to capture face image"""
        self.ensure_one()
        return {
            'type': 'ir.actions.client',
            'tag': 'webcam_capture',
            'target': 'new',
            'context': {
                'attendance_id': self.id,
                'employee_id': self.employee_id.id,
            }
        }
    
    def action_verify_face_advanced(self):
        """Enhanced AI face verification with multiple checks"""
        for record in self:
            if not record.face_image:
                record.message_post(body="⚠ Chưa có ảnh để xác thực")
                continue
            
            # Simulate advanced AI face recognition
            base_score = random.uniform(70.0, 99.5)
            
            # Adjust based on reference image availability
            if record.face_match_reference:
                # Simulate face comparison
                comparison_result = {
                    'match_score': base_score,
                    'face_detected': True,
                    'quality_score': random.uniform(80, 100),
                    'liveness_check': random.choice([True, True, True, False]),  # 75% pass
                }
                
                record.face_comparison_data = json.dumps(comparison_result)
                
                if not comparison_result['liveness_check']:
                    base_score *= 0.6  # Reduce score if liveness fails
                    record.anomaly_detected = True
                    record.anomaly_type = 'face_mismatch'
                    record.anomaly_details = "Không pass kiểm tra liveness - có thể dùng ảnh"
            
            record.face_recognition_score = round(base_score, 2)
            record.face_verified = base_score >= 85.0
            
            status = "✓ Xác thực thành công" if record.face_verified else "✗ Xác thực thất bại"
            record.message_post(
                body=f"{status} - AI nhận diện: {record.face_recognition_score:.2f}%<br/>"
                     f"Phương thức: {dict(record._fields['face_capture_method'].selection).get(record.face_capture_method, 'N/A')}"
            )
    
    def action_approve_attendance(self):
        """Approve attendance record"""
        for record in self:
            record.write({
                'approval_state': 'approved',
                'approved_by': self.env.user.id,
                'approved_date': fields.Datetime.now(),
            })
            
            # Approve overtime if requested
            if record.overtime_requested > 0:
                record.overtime_approved = record.overtime_requested
                record.overtime_approval_state = 'approved'
            
            record.message_post(
                body=f"✓ Đã phê duyệt bởi {self.env.user.name}",
                subject="Chấm công được phê duyệt"
            )
    
    def action_reject_attendance(self):
        """Reject attendance record"""
        for record in self:
            record.write({
                'approval_state': 'rejected',
                'approved_by': self.env.user.id,
                'approved_date': fields.Datetime.now(),
            })
            
            if record.overtime_requested > 0:
                record.overtime_approval_state = 'rejected'
            
            record.message_post(
                body=f"✗ Từ chối bởi {self.env.user.name}<br/>Lý do: {record.approval_notes or 'Không ghi'}",
                subject="Chấm công bị từ chối"
            )
    
    def action_request_overtime(self):
        """Request overtime approval"""
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Đề xuất tăng ca',
            'res_model': 'simple.attendance',
            'res_id': self.id,
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'form_view_ref': 'fitdnu_hr_ai.attendance_overtime_request_form',
            }
        }
    
    def action_manual_attendance_entry(self):
        """Create manual attendance entry for forgot check-in/out"""
        return {
            'type': 'ir.actions.act_window',
            'name': 'Nhập chấm công thủ công',
            'res_model': 'simple.attendance',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_is_manual_entry': True,
                'default_manual_entry_by': self.env.user.id,
                'default_approval_state': 'submitted',
            }
        }
    
    @api.model
    def cron_auto_checkout_forgot(self):
        """Auto-checkout for employees who forgot to check out"""
        yesterday = fields.Date.subtract(fields.Date.today(), days=1)
        forgot_records = self.search([
            ('attendance_date', '=', yesterday),
            ('check_in_time', '!=', False),
            ('check_out_time', '=', False),
            ('approval_state', '=', 'draft'),
        ])
        
        for record in forgot_records:
            # Auto checkout at expected time
            expected_checkout = record.employee_id.check_out_time or 17.0
            record.write({
                'check_out_time': expected_checkout,
                'is_manual_entry': True,
                'manual_entry_reason': 'Tự động checkout do quên chấm công',
                'approval_state': 'submitted',
            })
            record.message_post(
                body=f"⏰ Hệ thống tự động checkout lúc {expected_checkout:.2f}h vì quên chấm công",
                subject="Auto-checkout"
            )
    
    def action_generate_hr_decision(self):
        """Generate HR decision based on attendance patterns"""
        self.ensure_one()
        
        # Analyze attendance history
        history = self.search([
            ('employee_id', '=', self.employee_id.id),
            ('attendance_date', '>=', fields.Date.subtract(fields.Date.today(), days=90))
        ])
        
        if not history:
            return
        
        # Calculate metrics
        total_days = len(history)
        late_count = len(history.filtered('is_late'))
        absent_count = len(history.filtered(lambda r: r.state == 'absent'))
        fraud_count = len(history.filtered(lambda r: r.fraud_risk_score >= 50))
        avg_pattern_score = sum(history.mapped('attendance_pattern_score')) / total_days if total_days > 0 else 0
        
        decision_text = f"""
### QUYẾT ĐỊNH NHÂN SỰ - PHÂN TÍCH CHẤM CÔNG

**Nhân viên**: {self.employee_id.name}
**Thời gian phân tích**: 90 ngày gần nhất

#### Thống kê:
- Tổng số ngày làm việc: {total_days}
- Số lần đi muộn: {late_count} ({late_count/total_days*100:.1f}%)
- Số ngày vắng: {absent_count}
- Cảnh báo gian lận: {fraud_count}
- Điểm pattern trung bình: {avg_pattern_score:.1f}%

#### Đánh giá:
"""
        
        if avg_pattern_score >= 95:
            decision_text += "✓ XUẤT SẮC - Nhân viên rất đều đặn, đề xuất: Khen thưởng\n"
        elif avg_pattern_score >= 85:
            decision_text += "✓ TỐT - Nhân viên làm việc ổn định\n"
        elif avg_pattern_score >= 70:
            decision_text += "⚠ TRUNG BÌNH - Cần theo dõi và nhắc nhở\n"
        else:
            decision_text += "✗ KÉM - Cần có biện pháp xử lý kỷ luật\n"
        
        if fraud_count > 0:
            decision_text += f"⚠ CẢN BÁO: Phát hiện {fraud_count} trường hợp nghi ngờ gian lận!\n"
        
        if late_count > total_days * 0.2:  # >20% late
            decision_text += f"⚠ CHÚ Ý: Tỷ lệ đi muộn cao ({late_count/total_days*100:.1f}%)\n"
        
        self.message_post(
            body=decision_text,
            subject="Phân tích & Quyết định nhân sự"
        )
        
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': 'Phân tích hoàn tất',
                'message': 'Đã tạo báo cáo quyết định nhân sự',
                'type': 'success',
                'sticky': False,
            }
        }
    
    @api.model_create_multi
    def create(self, vals_list):
        """Auto-detect anomalies when creating records"""
        records = super(SimpleAttendance, self).create(vals_list)
        records.action_detect_anomalies()
        return records
    
    def write(self, vals):
        """Auto-detect anomalies when updating records"""
        res = super(SimpleAttendance, self).write(vals)
        if any(field in vals for field in ['check_in_time', 'check_out_time', 'gps_latitude', 'gps_longitude', 'face_recognition_score']):
            self.action_detect_anomalies()
        return res
    
    def action_approve_late_reason(self):
        """Approve late reason"""
        for record in self:
            record.late_reason_status = 'approved'
            record.late_approved_by = self.env.user
            record.late_approved_date = fields.Datetime.now()
    
    @api.model
    def cron_auto_checkout_missing(self):
        """Cron job: Tự động check-out cho những bản ghi quên check-out
        Chạy mỗi ngày lúc 23:00
        """
        yesterday = fields.Date.subtract(fields.Date.today(), days=1)
        missing_records = self.search([
            ('attendance_date', '=', yesterday),
            ('check_in_time', '!=', False),
            ('check_out_time', '=', False),
        ])
        
        for record in missing_records:
            # Auto check-out at expected time or 18:00
            auto_checkout_time = record.employee_id.check_out_time or 18.0
            record.write({
                'check_out_time': auto_checkout_time,
                'is_manual_entry': True,
                'manual_entry_reason': 'Hệ thống tự động check-out (quên chấm công ra)',
                'manual_entry_by': self.env.ref('base.user_admin').id,
                'manual_entry_date': fields.Datetime.now(),
            })
            record.message_post(
                body=f'🤖 Hệ thống tự động check-out lúc {auto_checkout_time:.2f} (quên chấm công)',
                subject='Auto Check-out'
            )
        
        return True
    
    def action_reject_late_reason(self):
        """Reject late reason"""
        for record in self:
            if record.is_late and record.late_reason:
                record.write({
                    'late_reason_status': 'rejected',
                    'late_approved_by': self.env.user.id,
                    'late_approved_date': fields.Datetime.now(),
                })
                record.message_post(body=f"✗ Từ chối lý do đi muộn bởi {self.env.user.name}")
    
    @api.model
    def cron_remind_missing_checkout(self):
        """Scheduled action: Remind employees who forgot to checkout"""
        today = fields.Date.today()
        missing_checkout_records = self.search([
            ('attendance_date', '=', today),
            ('check_in_time', '!=', False),
            ('check_out_time', '=', False),
        ])
        
        for record in missing_checkout_records:
            # Send notification to employee
            if record.employee_id.user_id:
                record.employee_id.user_id.notify_warning(
                    message=f"Bạn chưa checkout hôm nay ({today}). Vui lòng kiểm tra!",
                    title="Nhắc nhở: Thiếu giờ ra"
                )
            
            # Post message on record
            record.message_post(
                body=f"⏰ Nhắc nhở tự động: Nhân viên chưa checkout ngày {today}",
                subject="Thiếu giờ checkout"
            )    
    # ============================================
    # WORKFLOW APPROVAL ACTIONS
    # ============================================
    
    def action_submit_for_approval(self):
        """Submit attendance for approval"""
        for record in self:
            if record.approval_state == 'draft':
                record.write({
                    'approval_state': 'submitted',
                })
                record.message_post(
                    body=f"📤 Gửi phê duyệt bởi {self.env.user.name}",
                    subject="Gửi phê duyệt"
                )
                # Send notification to manager
                if record.employee_id.parent_id and record.employee_id.parent_id.user_id:
                    record.employee_id.parent_id.user_id.notify_info(
                        message=f"Chấm công của {record.employee_id.name} cần phê duyệt",
                        title="Yêu cầu phê duyệt chấm công"
                    )
        return True
    
    def action_approve(self):
        """Approve attendance"""
        for record in self:
            if record.approval_state == 'submitted':
                record.write({
                    'approval_state': 'approved',
                    'approved_by': self.env.user.id,
                    'approved_date': fields.Datetime.now(),
                })
                record.message_post(
                    body=f"✅ Đã phê duyệt bởi {self.env.user.name}",
                    subject="Phê duyệt"
                )
                # Notify employee
                if record.employee_id.user_id:
                    record.employee_id.user_id.notify_success(
                        message=f"Chấm công ngày {record.attendance_date} đã được phê duyệt",
                        title="Phê duyệt thành công"
                    )
        return True
    
    def action_reject(self):
        """Reject attendance"""
        for record in self:
            if record.approval_state == 'submitted':
                record.write({
                    'approval_state': 'rejected',
                    'approved_by': self.env.user.id,
                    'approved_date': fields.Datetime.now(),
                })
                record.message_post(
                    body=f"❌ Đã từ chối bởi {self.env.user.name}",
                    subject="Từ chối"
                )
                # Notify employee
                if record.employee_id.user_id:
                    record.employee_id.user_id.notify_warning(
                        message=f"Chấm công ngày {record.attendance_date} đã bị từ chối",
                        title="Từ chối phê duyệt"
                    )
        return True
    
    def action_reset_to_draft(self):
        """Reset to draft"""
        for record in self:
            record.write({
                'approval_state': 'draft',
                'approved_by': False,
                'approved_date': False,
            })
            record.message_post(
                body=f"🔄 Chuyển về nháp bởi {self.env.user.name}",
                subject="Chuyển về nháp"
            )
        return True