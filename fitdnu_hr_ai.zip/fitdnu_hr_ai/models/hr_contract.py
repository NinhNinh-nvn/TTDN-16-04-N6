# -*- coding: utf-8 -*-

from odoo import models, fields, api
from datetime import datetime

class HrContract(models.Model):
    _name = 'hr.contract.extended'
    _description = 'Quản lý Hợp đồng Nhân viên'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _rec_name = 'contract_number'

    contract_number = fields.Char(string='Số hợp đồng', required=True, tracking=True)
    employee_id = fields.Many2one('simple.employee', string='Nhân viên', required=True, tracking=True)
    contract_type = fields.Selection([
        ('indefinite', 'Không xác định thời hạn'),
        ('fixed', 'Xác định thời hạn'),
        ('seasonal', 'Theo mùa vụ'),
        ('probation', 'Thử việc'),
    ], string='Loại hợp đồng', required=True, default='fixed', tracking=True)
    
    start_date = fields.Date(string='Ngày bắt đầu', required=True, tracking=True)
    end_date = fields.Date(string='Ngày kết thúc', tracking=True)
    
    wage = fields.Float(string='Lương cơ bản', required=True, tracking=True)
    allowance = fields.Float(string='Phụ cấp', default=0, tracking=True)
    bonus = fields.Float(string='Thưởng', default=0)
    
    state = fields.Selection([
        ('draft', 'Nháp'),
        ('running', 'Đang thực hiện'),
        ('expired', 'Hết hạn'),
        ('cancelled', 'Đã hủy'),
    ], string='Trạng thái', default='draft', tracking=True)
    
    department_id = fields.Many2one('hr.department', string='Phòng ban', related='employee_id.department_id', store=True)
    job_id = fields.Char(string='Chức vụ', related='employee_id.position', store=True)
    
    notes = fields.Text(string='Ghi chú')
    attachment_ids = fields.Many2many('ir.attachment', string='Tài liệu đính kèm')
    
    total_salary = fields.Float(string='Tổng lương', compute='_compute_total_salary', store=True)
    contract_duration = fields.Integer(string='Thời hạn (tháng)', compute='_compute_duration')
    
    @api.depends('wage', 'allowance', 'bonus')
    def _compute_total_salary(self):
        for record in self:
            record.total_salary = record.wage + record.allowance + record.bonus
    
    @api.depends('start_date', 'end_date')
    def _compute_duration(self):
        for record in self:
            if record.start_date and record.end_date:
                delta = record.end_date - record.start_date
                record.contract_duration = delta.days // 30
            else:
                record.contract_duration = 0
    
    def action_confirm(self):
        self.state = 'running'
    
    def action_expire(self):
        self.state = 'expired'
    
    def action_cancel(self):
        self.state = 'cancelled'
