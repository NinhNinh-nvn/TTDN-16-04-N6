# -*- coding: utf-8 -*-
from . import employee
from . import attendance
from . import attendance_ai_integration
# from . import attendance_ai_engine  # DISABLED: AI Engine models removed
from . import salary
from . import hr_contract
from . import hr_work_history
from . import hr_training_history
from . import hr_reward_discipline
from . import hr_payroll
from . import hr_department


