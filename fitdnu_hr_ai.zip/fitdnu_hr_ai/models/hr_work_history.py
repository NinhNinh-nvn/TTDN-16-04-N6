# -*- coding: utf-8 -*-

from odoo import models, fields, api

class HrWorkHistory(models.Model):
    _name = 'hr.work.history'
    _description = 'Lịch sử Công tác'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'start_date desc'

    employee_id = fields.Many2one('simple.employee', string='Nhân viên', required=True, tracking=True)
    
    company_name = fields.Char(string='Tên công ty', required=True)
    position = fields.Char(string='Chức vụ', required=True)
    
    start_date = fields.Date(string='Ngày bắt đầu', required=True)
    end_date = fields.Date(string='Ngày kết thúc')
    
    is_current = fields.Boolean(string='Hiện tại', default=False)
    
    responsibilities = fields.Text(string='Trách nhiệm công việc')
    achievements = fields.Text(string='Thành tích')
    reason_leave = fields.Text(string='Lý do nghỉ việc')
    
    reference_name = fields.Char(string='Người tham chiếu')
    reference_contact = fields.Char(string='Liên hệ tham chiếu')
    
    department = fields.Char(string='Phòng ban')
    salary = fields.Float(string='Mức lương')
    
    duration_months = fields.Integer(string='Thời gian (tháng)', compute='_compute_duration')
    
    notes = fields.Text(string='Ghi chú')
    
    @api.depends('start_date', 'end_date')
    def _compute_duration(self):
        for record in self:
            if record.start_date:
                end = record.end_date or fields.Date.today()
                delta = end - record.start_date
                record.duration_months = delta.days // 30
            else:
                record.duration_months = 0
    
    @api.onchange('is_current')
    def _onchange_is_current(self):
        if self.is_current:
            self.end_date = False
