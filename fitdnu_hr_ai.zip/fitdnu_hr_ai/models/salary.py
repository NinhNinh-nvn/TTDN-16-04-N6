# -*- coding: utf-8 -*-
from odoo import models, fields, api
import random

class SimpleSalary(models.Model):
    _name = 'simple.salary'
    _description = 'Bảng lương (AI)'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'salary_date desc'

    employee_id = fields.Many2one('simple.employee', 'Nhân viên', required=True, tracking=True)
    salary_date = fields.Date('Tháng lương', required=True, default=fields.Date.today, tracking=True)
    
    # Input fields
    base_salary = fields.Float('Lương cơ bản', compute='_compute_from_employee')
    allowance_amount = fields.Float('Tiền trợ cấp', compute='_compute_from_employee')
    actual_working_days = fields.Integer('Số ngày công (thực)', default=22)
    
    # Calculated from attendance
    present_days = fields.Integer('Ngày có mặt', compute='_compute_attendance_data', store=True)
    late_days = fields.Integer('Ngày đi muộn', compute='_compute_attendance_data', store=True)
    absent_days = fields.Integer('Ngày vắng', compute='_compute_attendance_data', store=True)
    overtime_hours = fields.Float('Giờ OT', compute='_compute_overtime_total', store=True)
    
    # AI Features - Salary Calculations
    gross_salary = fields.Float('Lương tổng', compute='_compute_gross_salary', store=True)
    insurance_amount = fields.Float('Bảo hiểm (8%)', compute='_compute_insurance', store=True)
    late_deduction = fields.Float('Trừ đi muộn', compute='_compute_late_deduction', store=True)
    absent_deduction = fields.Float('Trừ vắng', compute='_compute_absent_deduction', store=True)
    total_deduction = fields.Float('Tổng trừ', compute='_compute_total_deduction', store=True)
    net_salary = fields.Float('Lương thực', compute='_compute_net_salary', store=True)
    
    # AI Features - Predictions & Analytics
    predicted_salary_next_month = fields.Float('Dự đoán lương tháng sau', compute='_compute_predicted_salary')
    salary_trend = fields.Selection([
        ('increasing', 'Tăng'),
        ('stable', 'Ổn định'),
        ('decreasing', 'Giảm'),
    ], 'Xu hướng lương', compute='_compute_salary_trend', store=True)
    
    performance_score = fields.Float('Điểm hiệu suất (%)', compute='_compute_performance_score', store=True)
    attendance_quality_score = fields.Float('Điểm chất lượng chấm công (%)', compute='_compute_attendance_quality', store=True)
    
    # AI Anomaly Detection
    anomaly_detected = fields.Boolean('Phát hiện bất thường', default=False)
    anomaly_type = fields.Selection([
        ('unusual_overtime', 'OT bất thường'),
        ('low_attendance', 'Chấm công thấp'),
        ('high_deduction', 'Khấu trừ cao'),
        ('salary_spike', 'Lương tăng đột biến'),
    ], 'Loại bất thường')
    
    # AI Recommendations
    ai_recommendations = fields.Text('AI Đề xuất', compute='_compute_ai_recommendations')
    salary_insights = fields.Text('Phân tích lương', compute='_compute_salary_insights')
    optimization_suggestions = fields.Text('Gợi ý tối ưu', compute='_compute_optimization_suggestions')
    
    # Auto-calculation features
    auto_calculated = fields.Boolean('Tính lương tự động', default=False)
    calculation_confidence = fields.Float('Độ tin cậy tính toán (%)', compute='_compute_calculation_confidence')

    @api.depends('employee_id')
    def _compute_from_employee(self):
        for record in self:
            if record.employee_id:
                record.base_salary = record.employee_id.base_salary
                record.allowance_amount = record.employee_id.allowance_amount
            else:
                record.base_salary = 0
                record.allowance_amount = 0

    @api.depends('employee_id', 'salary_date')
    def _compute_attendance_data(self):
        for record in self:
            if record.employee_id and record.salary_date:
                year = record.salary_date.year
                month = record.salary_date.month
                
                # Calculate next month correctly
                next_month = month + 1
                next_year = year
                if next_month > 12:
                    next_month = 1
                    next_year = year + 1
                
                attendances = self.env['simple.attendance'].search([
                    ('employee_id', '=', record.employee_id.id),
                    ('attendance_date', '>=', f'{year}-{month:02d}-01'),
                    ('attendance_date', '<', f'{next_year}-{next_month:02d}-01'),
                ])
                
                record.present_days = len(attendances.filtered(lambda x: x.state == 'present'))
                record.late_days = len(attendances.filtered(lambda x: x.state == 'late'))
                record.absent_days = len(attendances.filtered(lambda x: x.state == 'absent'))
            else:
                record.present_days = 0
                record.late_days = 0
                record.absent_days = 0

    @api.depends('employee_id', 'salary_date')
    def _compute_overtime_total(self):
        for record in self:
            if record.employee_id and record.salary_date:
                year = record.salary_date.year
                month = record.salary_date.month
                
                # Calculate next month correctly
                next_month = month + 1
                next_year = year
                if next_month > 12:
                    next_month = 1
                    next_year = year + 1
                
                attendances = self.env['simple.attendance'].search([
                    ('employee_id', '=', record.employee_id.id),
                    ('attendance_date', '>=', f'{year}-{month:02d}-01'),
                    ('attendance_date', '<', f'{next_year}-{next_month:02d}-01'),
                ])
                
                record.overtime_hours = sum(a.overtime_hours for a in attendances)
            else:
                record.overtime_hours = 0.0

    @api.depends('base_salary', 'allowance_amount', 'present_days', 'actual_working_days')
    def _compute_gross_salary(self):
        for record in self:
            if record.actual_working_days > 0:
                daily_salary = (record.base_salary + record.allowance_amount) / record.actual_working_days
                record.gross_salary = daily_salary * record.present_days
            else:
                record.gross_salary = 0.0

    @api.depends('gross_salary')
    def _compute_insurance(self):
        for record in self:
            record.insurance_amount = record.gross_salary * 0.08

    @api.depends('late_days')
    def _compute_late_deduction(self):
        for record in self:
            record.late_deduction = record.late_days * 50000  # 50k per late day

    @api.depends('absent_days', 'base_salary', 'actual_working_days')
    def _compute_absent_deduction(self):
        for record in self:
            if record.actual_working_days > 0:
                daily_salary = record.base_salary / record.actual_working_days
                record.absent_deduction = daily_salary * record.absent_days
            else:
                record.absent_deduction = 0.0

    @api.depends('insurance_amount', 'late_deduction', 'absent_deduction')
    def _compute_total_deduction(self):
        for record in self:
            record.total_deduction = record.insurance_amount + record.late_deduction + record.absent_deduction

    @api.depends('gross_salary', 'total_deduction')
    def _compute_net_salary(self):
        for record in self:
            record.net_salary = record.gross_salary - record.total_deduction
    
    @api.depends('employee_id', 'salary_date')
    def _compute_predicted_salary(self):
        """AI: Predict next month salary based on trends"""
        for record in self:
            if not record.employee_id or not record.salary_date:
                record.predicted_salary_next_month = 0.0
                continue
            
            # Get last 3 months salary data
            past_salaries = self.search([
                ('employee_id', '=', record.employee_id.id),
                ('salary_date', '<', record.salary_date)
            ], limit=3, order='salary_date desc')
            
            if len(past_salaries) >= 2:
                # Calculate average growth rate
                salaries = [record.net_salary] + past_salaries.mapped('net_salary')
                avg_salary = sum(salaries) / len(salaries)
                
                # Simple trend prediction
                recent_avg = sum(salaries[:2]) / 2
                old_avg = sum(salaries[2:]) / max(1, len(salaries[2:]))
                
                if old_avg > 0:
                    growth_rate = (recent_avg - old_avg) / old_avg
                    record.predicted_salary_next_month = record.net_salary * (1 + growth_rate)
                else:
                    record.predicted_salary_next_month = record.net_salary
            else:
                record.predicted_salary_next_month = record.net_salary
    
    @api.depends('predicted_salary_next_month', 'net_salary')
    def _compute_salary_trend(self):
        """AI: Determine salary trend"""
        for record in self:
            if not record.predicted_salary_next_month or not record.net_salary:
                record.salary_trend = 'stable'
                continue
            
            diff_percent = ((record.predicted_salary_next_month - record.net_salary) / record.net_salary * 100) if record.net_salary > 0 else 0
            
            if diff_percent > 5:
                record.salary_trend = 'increasing'
            elif diff_percent < -5:
                record.salary_trend = 'decreasing'
            else:
                record.salary_trend = 'stable'
    
    @api.depends('present_days', 'late_days', 'absent_days', 'actual_working_days')
    def _compute_performance_score(self):
        """AI: Calculate employee performance score"""
        for record in self:
            if record.actual_working_days <= 0:
                record.performance_score = 0.0
                continue
            
            # Base attendance score (70% weight)
            attendance_rate = (record.present_days / record.actual_working_days * 100) if record.actual_working_days > 0 else 0
            
            # Punctuality score (20% weight)
            punctuality_rate = 100 - ((record.late_days / record.actual_working_days * 100) if record.actual_working_days > 0 else 0)
            
            # Presence score (10% weight)
            presence_rate = 100 - ((record.absent_days / record.actual_working_days * 100) if record.actual_working_days > 0 else 0)
            
            # Weighted average
            performance = (attendance_rate * 0.7) + (punctuality_rate * 0.2) + (presence_rate * 0.1)
            record.performance_score = round(min(100, performance), 2)
    
    @api.depends('employee_id', 'salary_date')
    def _compute_attendance_quality(self):
        """AI: Analyze attendance quality from AI system"""
        for record in self:
            if not record.employee_id or not record.salary_date:
                record.attendance_quality_score = 0.0
                continue
            
            year = record.salary_date.year
            month = record.salary_date.month
            
            # Calculate next month correctly
            next_month = month + 1
            next_year = year
            if next_month > 12:
                next_month = 1
                next_year = year + 1
            
            attendances = self.env['simple.attendance'].search([
                ('employee_id', '=', record.employee_id.id),
                ('attendance_date', '>=', f'{year}-{month:02d}-01'),
                ('attendance_date', '<', f'{next_year}-{next_month:02d}-01'),
            ])
            
            if not attendances:
                record.attendance_quality_score = 0.0
                continue
            
            # Calculate average confidence score and pattern score
            confidence_scores = attendances.mapped('confidence_score')
            pattern_scores = attendances.mapped('attendance_pattern_score')
            
            avg_confidence = sum(confidence_scores) / len(confidence_scores) if confidence_scores else 0
            avg_pattern = sum(pattern_scores) / len(pattern_scores) if pattern_scores else 0
            
            # Combined quality score
            quality = (avg_confidence * 0.6) + (avg_pattern * 0.4)
            record.attendance_quality_score = round(quality, 2)
    
    @api.depends('overtime_hours', 'absent_days', 'total_deduction', 'net_salary')
    def _compute_ai_recommendations(self):
        """AI: Generate personalized recommendations"""
        for record in self:
            recommendations = []
            
            # Overtime analysis
            if record.overtime_hours > 40:
                recommendations.append("⚠️ OT cao: Cân nhắc tuyển thêm nhân sự hoặc tối ưu quy trình")
            elif record.overtime_hours > 20:
                recommendations.append("💡 OT trung bình: Theo dõi để tránh burnout")
            
            # Attendance analysis
            if record.absent_days > 5:
                recommendations.append("⚠️ Vắng mặt nhiều: Cần kiểm tra sức khỏe/động lực làm việc")
            elif record.present_days == record.actual_working_days:
                recommendations.append("✓ Chấm công hoàn hảo: Xem xét khen thưởng chuyên cần")
            
            # Performance analysis
            if record.performance_score >= 95:
                recommendations.append("⭐ Hiệu suất xuất sắc: Đề xuất thưởng/tăng lương")
            elif record.performance_score < 70:
                recommendations.append("⚠️ Hiệu suất thấp: Cần đào tạo/hỗ trợ")
            
            # Deduction analysis
            deduction_rate = (record.total_deduction / record.gross_salary * 100) if record.gross_salary > 0 else 0
            if deduction_rate > 20:
                recommendations.append(f"💰 Khấu trừ cao ({deduction_rate:.1f}%): Xem xét điều chỉnh chính sách")
            
            record.ai_recommendations = "\n".join(recommendations) if recommendations else "Không có đề xuất đặc biệt"
    
    @api.depends('net_salary', 'performance_score', 'salary_trend')
    def _compute_salary_insights(self):
        """AI: Generate salary insights"""
        for record in self:
            insights = []
            
            # Salary level analysis
            if record.net_salary > 0:
                insights.append(f"💵 Lương thực lãnh: {record.net_salary:,.0f} VNĐ")
            
            # Performance correlation
            if record.performance_score >= 90:
                insights.append(f"📊 Hiệu suất: {record.performance_score:.1f}% - Xuất sắc")
            elif record.performance_score >= 70:
                insights.append(f"📊 Hiệu suất: {record.performance_score:.1f}% - Tốt")
            else:
                insights.append(f"📊 Hiệu suất: {record.performance_score:.1f}% - Cần cải thiện")
            
            # Trend analysis
            if record.salary_trend == 'increasing':
                insights.append(f"📈 Xu hướng tăng: Dự đoán {record.predicted_salary_next_month:,.0f} VNĐ")
            elif record.salary_trend == 'decreasing':
                insights.append(f"📉 Xu hướng giảm: Dự đoán {record.predicted_salary_next_month:,.0f} VNĐ")
            else:
                insights.append("📊 Xu hướng ổn định")
            
            # Quality score
            if record.attendance_quality_score > 0:
                insights.append(f"🎯 Chất lượng chấm công: {record.attendance_quality_score:.1f}%")
            
            record.salary_insights = "\n".join(insights) if insights else "Chưa có dữ liệu phân tích"
    
    @api.depends('late_deduction', 'absent_deduction', 'overtime_hours')
    def _compute_optimization_suggestions(self):
        """AI: Suggest salary optimizations"""
        for record in self:
            suggestions = []
            
            # Reduce deductions
            if record.late_deduction > 0:
                potential_save = record.late_deduction
                suggestions.append(f"⏰ Giảm đi muộn → Tiết kiệm {potential_save:,.0f} VNĐ")
            
            if record.absent_deduction > 0:
                potential_save = record.absent_deduction
                suggestions.append(f"📅 Cải thiện chuyên cần → Tiết kiệm {potential_save:,.0f} VNĐ")
            
            # Optimize overtime
            if record.overtime_hours > 0:
                ot_rate = record.base_salary / (record.actual_working_days * 8) * 1.5 if record.actual_working_days > 0 else 0
                potential_earn = record.overtime_hours * ot_rate
                suggestions.append(f"💪 Làm thêm {record.overtime_hours:.1f}h → Thêm {potential_earn:,.0f} VNĐ")
            
            # Attendance improvement
            if record.present_days < record.actual_working_days:
                missing_days = record.actual_working_days - record.present_days
                daily_salary = record.base_salary / record.actual_working_days if record.actual_working_days > 0 else 0
                potential_earn = missing_days * daily_salary
                suggestions.append(f"📈 Tăng {missing_days} ngày công → Thêm {potential_earn:,.0f} VNĐ")
            
            record.optimization_suggestions = "\n".join(suggestions) if suggestions else "Không có gợi ý tối ưu"
    
    @api.depends('present_days', 'actual_working_days', 'performance_score', 'attendance_quality_score')
    def _compute_calculation_confidence(self):
        """AI: Calculate confidence in salary calculation"""
        for record in self:
            confidence = 100.0
            
            # Deduct for missing attendance data
            if record.present_days < record.actual_working_days * 0.8:
                confidence -= 20
            
            # Deduct for low performance score
            if record.performance_score < 50:
                confidence -= 15
            
            # Deduct for low attendance quality
            if record.attendance_quality_score < 70:
                confidence -= 15
            
            # Deduct if anomaly detected
            if record.anomaly_detected:
                confidence -= 20
            
            record.calculation_confidence = max(0, confidence)
    
    def action_auto_calculate_salary(self):
        """AI: Auto-calculate salary from attendance data"""
        for record in self:
            # Mark as auto-calculated
            record.auto_calculated = True
            
            # Trigger all computations
            record._compute_attendance_data()
            record._compute_overtime_total()
            record._compute_gross_salary()
            record._compute_insurance()
            record._compute_late_deduction()
            record._compute_absent_deduction()
            record._compute_total_deduction()
            record._compute_net_salary()
            
            # Log the action
            record.message_post(
                body=f"✓ AI tự động tính lương thành công<br/>"
                     f"Lương thực lãnh: {record.net_salary:,.0f} VNĐ<br/>"
                     f"Độ tin cậy: {record.calculation_confidence:.1f}%"
            )
    
    def action_detect_salary_anomalies(self):
        """AI: Detect anomalies in salary data"""
        for record in self:
            # Check unusual overtime
            if record.overtime_hours > 60:
                record.anomaly_detected = True
                record.anomaly_type = 'unusual_overtime'
                record.message_post(body=f"⚠️ Phát hiện OT bất thường: {record.overtime_hours:.1f} giờ")
                continue
            
            # Check low attendance
            attendance_rate = (record.present_days / record.actual_working_days * 100) if record.actual_working_days > 0 else 0
            if attendance_rate < 50:
                record.anomaly_detected = True
                record.anomaly_type = 'low_attendance'
                record.message_post(body=f"⚠️ Tỷ lệ chấm công thấp: {attendance_rate:.1f}%")
                continue
            
            # Check high deduction
            deduction_rate = (record.total_deduction / record.gross_salary * 100) if record.gross_salary > 0 else 0
            if deduction_rate > 30:
                record.anomaly_detected = True
                record.anomaly_type = 'high_deduction'
                record.message_post(body=f"⚠️ Khấu trừ cao: {deduction_rate:.1f}%")
                continue
            
            # Check salary spike
            past_salary = self.search([
                ('employee_id', '=', record.employee_id.id),
                ('salary_date', '<', record.salary_date)
            ], limit=1, order='salary_date desc')
            
            if past_salary:
                increase_rate = ((record.net_salary - past_salary.net_salary) / past_salary.net_salary * 100) if past_salary.net_salary > 0 else 0
                if abs(increase_rate) > 50:
                    record.anomaly_detected = True
                    record.anomaly_type = 'salary_spike'
                    record.message_post(body=f"⚠️ Lương thay đổi đột biến: {increase_rate:+.1f}%")
                    continue
            
            # No anomaly
            record.anomaly_detected = False
            record.anomaly_type = False
