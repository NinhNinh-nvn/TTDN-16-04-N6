# -*- coding: utf-8 -*-
from odoo import models, fields, api
from odoo.exceptions import ValidationError

class SimpleEmployee(models.Model):
    _name = 'simple.employee'
    _description = 'Nhân viên'

    name = fields.Char('Họ tên', required=True)
    employee_code = fields.Char('Mã nhân viên')
    phone = fields.Char('Điện thoại')
    email = fields.Char('Email')
    department = fields.Char('Phòng ban')
    position = fields.Char('Chức vụ')
    date_join = fields.Date('Ngày bắt đầu')
    
    # Phòng ban - Link tới hr.department
    department_id = fields.Many2one('hr.department', string='Phòng Ban', 
                                     help='Chọn phòng ban làm việc')
    
    # Thông tin tài liệu
    identity_card = fields.Char('Số Căn Cước Công Dân')
    identity_card_image = fields.Image(string='Ảnh Căn Cước Công Dân', max_width=200, max_height=200,
                                        help='Ảnh mặt trước hoặc mặt sau của CCCD')
    identity_card_file = fields.Binary(string='File Căn Cước', attachment=True,
                                        help='Upload file PDF/JPG/PNG của CCCD')
    identity_card_filename = fields.Char(string='Tên file CCCD')
    
    degree_image = fields.Image(string='Ảnh Bằng Cấp', max_width=200, max_height=200,
                                help='Ảnh bằng cấp cao nhất')
    degree_file = fields.Binary(string='File Bằng Cấp', attachment=True,
                                help='Upload file PDF/JPG/PNG của bằng cấp')
    degree_filename = fields.Char(string='Tên file Bằng cấp')
    
    # Employee profile image
    image = fields.Image(string='Ảnh đại diện nhân viên', max_width=1920, max_height=1920)
    
    # Salary config
    base_salary = fields.Float('Lương cơ bản')
    allowance_amount = fields.Float('Tiền trợ cấp')
    
    # Attendance config
    work_hours_per_day = fields.Float('Giờ làm/ngày', default=8.0)
    check_in_time = fields.Float('Giờ vào', help='Giờ bắt đầu làm (0-24)', default=8.0)
    check_out_time = fields.Float('Giờ ra', help='Giờ kết thúc làm (0-24)', default=17.0)
    late_threshold_minutes = fields.Integer('Ngưỡng đi muộn (phút)', default=5)
    
    state = fields.Selection([
        ('active', 'Đang làm'),
        ('inactive', 'Nghỉ việc'),
        ('maternity', 'Nghỉ thai sản'),
        ('on_leave', 'Đang nghỉ phép'),
    ], 'Trạng thái', default='active')
    
    # Relations
    attendance_ids = fields.One2many('simple.attendance', 'employee_id', 'Chấm công')
    salary_ids = fields.One2many('simple.salary', 'employee_id', 'Bảng lương')
    work_history_ids = fields.One2many('hr.work.history', 'employee_id', 'Lịch sử công việc')

    _sql_constraints = [
        ('employee_code_unique', 'unique(employee_code)', 'Mã nhân viên đã tồn tại. Vui lòng dùng mã khác.'),
    ]

    @api.constrains('name', 'phone', 'email')
    def _check_duplicate_employee(self):
        for rec in self:
            # Skip if creating without enough identifiers
            identifiers = [rec.name, rec.phone, rec.email]
            if not any(identifiers):
                continue
            domain = ['|', ('phone', '=', rec.phone), ('email', '=', rec.email)]
            dup = self.search([('name', '=', rec.name), ('id', '!=', rec.id)] + domain, limit=1)
            if dup:
                raise ValidationError('Phát hiện trùng lặp nhân viên dựa trên tên + (SĐT/Email). Vui lòng kiểm tra trước khi tạo.')
