/** @odoo-module */

// Direct override: wrap getDomain to catch and fix malformed domains
// This runs immediately to patch Odoo before it crashes

(function() {
    // Try to patch via odoo.define (AMD)
    if (typeof odoo !== "undefined" && odoo.define) {
        odoo.define("fitdnu_hr_ai.domain_patch", function(require) {
            // Delay patch until Odoo is fully loaded
            setTimeout(function() {
                try {
                    var legacy_require = require;
                    var ControlPanelModelExt = legacy_require("web.model.Model").extend({
                        getDomain: function() {
                            try {
                                return this._super.apply(this, arguments);
                            } catch (e) {
                                console.warn("[fitdnu_hr_ai] getDomain error caught, returning []:", e.message);
                                return [];
                            }
                        }
                    });
                } catch (err) {
                    console.debug("[fitdnu_hr_ai] AMD patch setup:", err.message);
                }
            }, 100);
        });
    }
    
    // Global unhandled promise rejection handler
    window.addEventListener("unhandledrejection", function(event) {
        var msg = String(event.reason || "");
        if (msg.includes("Control panel model extension failed to evaluate domain")) {
            console.warn("[fitdnu_hr_ai] Caught domain error, preventing white screen");
            event.preventDefault?.();
            // Redirect to home to recover
            window.location.href = "/web";
        }
    });
    
    // Also try to override at window level
    if (window.owl) {
        var orig_define = window.define;
        window.define = function(name, deps, factory) {
            if (name.includes("ControlPanelModel")) {
                var wrappedFactory = function() {
                    var result = factory.apply(this, arguments);
                    if (result && result.prototype && result.prototype.getDomain) {
                        var origGetDomain = result.prototype.getDomain;
                        result.prototype.getDomain = function() {
                            try {
                                return origGetDomain.apply(this, arguments);
                            } catch (e) {
                                console.warn("[fitdnu_hr_ai] Domain error intercepted:", e.message);
                                return [];
                            }
                        };
                    }
                    return result;
                };
                return orig_define(name, deps, wrappedFactory);
            }
            return orig_define.apply(this, arguments);
        };
    }
})();
