/** @odoo-module **/

import { registry } from "@web/core/registry";
import { Component, useState, useRef, onWillUnmount } from "@odoo/owl";
import { useService } from "@web/core/utils/hooks";

/**
 * Webcam Widget - Bật camera thật để chụp ảnh chấm công
 */
export class WebcamCaptureWidget extends Component {
    setup() {
        this.notification = useService("notification");
        this.state = useState({
            isActive: false,
            isCameraOpen: false,
            capturedImage: null,
            stream: null,
        });
        
        this.videoRef = useRef("videoElement");
        this.canvasRef = useRef("canvasElement");
        
        onWillUnmount(() => {
            this.stopCamera();
        });
    }

    async openCamera() {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({
                video: { 
                    width: { ideal: 1280 },
                    height: { ideal: 720 },
                    facingMode: "user" 
                },
                audio: false
            });
            
            this.state.stream = stream;
            this.state.isCameraOpen = true;
            this.state.isActive = true;
            
            setTimeout(() => {
                const video = this.videoRef.el;
                if (video) {
                    video.srcObject = stream;
                    video.play();
                }
            }, 100);
            
            this.notification.add("Camera đã sẵn sàng! Hãy chụp ảnh.", {
                type: "success",
            });
        } catch (error) {
            console.error("Camera error:", error);
            this.notification.add("Không thể bật camera. Vui lòng kiểm tra quyền truy cập.", {
                type: "danger",
            });
        }
    }

    stopCamera() {
        if (this.state.stream) {
            this.state.stream.getTracks().forEach(track => track.stop());
            this.state.stream = null;
        }
        this.state.isCameraOpen = false;
    }

    async capturePhoto() {
        const video = this.videoRef.el;
        const canvas = this.canvasRef.el;
        
        if (!video || !canvas) {
            this.notification.add("Lỗi: Không tìm thấy video hoặc canvas", { type: "danger" });
            return;
        }
        
        canvas.width = video.videoWidth || 640;
        canvas.height = video.videoHeight || 480;
        
        const ctx = canvas.getContext('2d');
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        
        const imageData = canvas.toDataURL('image/jpeg', 0.9);
        this.state.capturedImage = imageData;
        
        this.stopCamera();
        
        await this.saveToField(imageData);
        
        this.notification.add("✅ Đã chụp ảnh thành công!", {
            type: "success",
        });
    }

    async saveToField(imageData) {
        try {
            const base64Data = imageData.split(',')[1];
            
            await this.props.record.update({
                [this.props.name]: base64Data,
            });
        } catch (error) {
            console.error("Save error:", error);
            this.notification.add("Lỗi khi lưu ảnh", { type: "danger" });
        }
    }

    retakePhoto() {
        this.state.capturedImage = null;
        this.openCamera();
    }

    closeWidget() {
        this.stopCamera();
        this.state.capturedImage = null;
        this.state.isActive = false;
    }
}

WebcamCaptureWidget.template = "fitdnu_hr_ai.WebcamCaptureWidget";

export const webcamCaptureWidget = {
    component: WebcamCaptureWidget,
};

registry.category("fields").add("webcam_capture", webcamCaptureWidget);
