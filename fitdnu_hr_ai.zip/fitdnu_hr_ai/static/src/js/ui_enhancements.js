/** @odoo-module **/

import { registry } from "@web/core/registry";
import { Component, useState, onMounted, onWillUnmount } from "@odoo/owl";

/**
 * UI Enhancements for FITDNU HR AI v3.1
 * - Dark Mode Toggle
 * - Scroll to Top
 * - Smooth Animations
 */

class UIEnhancementsService {
    constructor() {
        this.darkMode = localStorage.getItem('darkMode') === 'true';
        this.init();
    }

    init() {
        // Initialize dark mode
        this.applyDarkMode();
        
        // Add scroll to top button
        this.addScrollToTopButton();
        
        // Add dark mode toggle
        this.addDarkModeToggle();
        
        // Initialize tooltips
        this.initTooltips();
    }

    applyDarkMode() {
        if (this.darkMode) {
            document.body.classList.add('dark-mode');
        } else {
            document.body.classList.remove('dark-mode');
        }
    }

    toggleDarkMode() {
        this.darkMode = !this.darkMode;
        localStorage.setItem('darkMode', this.darkMode);
        this.applyDarkMode();
        
        // Smooth transition
        document.body.style.transition = 'all 0.3s ease';
        setTimeout(() => {
            document.body.style.transition = '';
        }, 300);
    }

    addDarkModeToggle() {
        const toggle = document.createElement('button');
        toggle.className = 'dark-mode-toggle';
        toggle.innerHTML = this.darkMode ? '☀️' : '🌙';
        toggle.title = 'Toggle Dark Mode';
        toggle.setAttribute('data-tooltip', 'Chuyển đổi chế độ tối');
        
        toggle.addEventListener('click', () => {
            this.toggleDarkMode();
            toggle.innerHTML = this.darkMode ? '☀️' : '🌙';
            
            // Animation
            toggle.style.transform = 'scale(0.8) rotate(360deg)';
            setTimeout(() => {
                toggle.style.transform = '';
            }, 300);
        });
        
        document.body.appendChild(toggle);
    }

    addScrollToTopButton() {
        const button = document.createElement('button');
        button.className = 'scroll-to-top';
        button.innerHTML = '↑';
        button.title = 'Scroll to Top';
        
        button.addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
        
        // Show/hide based on scroll position
        window.addEventListener('scroll', () => {
            if (window.pageYOffset > 300) {
                button.classList.add('visible');
            } else {
                button.classList.remove('visible');
            }
        });
        
        document.body.appendChild(button);
    }

    initTooltips() {
        // Add tooltip class to elements with data-tooltip attribute
        document.querySelectorAll('[data-tooltip]').forEach(element => {
            element.classList.add('tooltip');
        });
    }

    showToast(message, type = 'info', duration = 3000) {
        const toast = document.createElement('div');
        toast.className = `toast alert-${type}`;
        
        const icon = {
            success: '✓',
            danger: '✗',
            warning: '⚠',
            info: 'ℹ'
        }[type] || 'ℹ';
        
        toast.innerHTML = `
            <i>${icon}</i>
            <span>${message}</span>
        `;
        
        let container = document.querySelector('.toast-container');
        if (!container) {
            container = document.createElement('div');
            container.className = 'toast-container';
            document.body.appendChild(container);
        }
        
        container.appendChild(toast);
        
        // Auto remove
        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateX(100%)';
            setTimeout(() => toast.remove(), 300);
        }, duration);
    }

    showLoading(target = document.body) {
        const loading = document.createElement('div');
        loading.className = 'loading-overlay';
        loading.innerHTML = `
            <div class="spinner"></div>
            <p>Đang tải...</p>
        `;
        loading.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 20px;
            z-index: 9999;
            color: white;
        `;
        target.appendChild(loading);
        return loading;
    }

    hideLoading(loading) {
        if (loading) {
            loading.style.opacity = '0';
            setTimeout(() => loading.remove(), 300);
        }
    }
}

// Initialize service when DOM is ready
let uiService;
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        uiService = new UIEnhancementsService();
    });
} else {
    uiService = new UIEnhancementsService();
}

// Export for use in other modules
export const uiEnhancementsService = {
    start() {
        return new UIEnhancementsService();
    },
};

registry.category("services").add("uiEnhancements", uiEnhancementsService);

/**
 * Enhanced Form Animations
 */
export class EnhancedFormView extends Component {
    setup() {
        onMounted(() => {
            this.addFormAnimations();
        });
    }

    addFormAnimations() {
        // Animate form fields on load
        const fields = document.querySelectorAll('.o_field_widget');
        fields.forEach((field, index) => {
            field.style.opacity = '0';
            field.style.transform = 'translateY(20px)';
            
            setTimeout(() => {
                field.style.transition = 'all 0.4s ease';
                field.style.opacity = '1';
                field.style.transform = 'translateY(0)';
            }, index * 50);
        });

        // Add focus animations
        document.querySelectorAll('input, select, textarea').forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement?.classList.add('field-focused');
            });
            
            input.addEventListener('blur', function() {
                this.parentElement?.classList.remove('field-focused');
            });
        });
    }
}

/**
 * Progress Bar Component
 */
export class ProgressBar extends Component {
    static template = "fitdnu_hr_ai.ProgressBar";
    static props = {
        value: { type: Number, optional: false },
        max: { type: Number, optional: true },
        label: { type: String, optional: true },
        color: { type: String, optional: true },
    };

    get percentage() {
        const max = this.props.max || 100;
        return Math.min(100, (this.props.value / max) * 100);
    }

    get progressStyle() {
        return `width: ${this.percentage}%`;
    }
}

// Add CSS for field-focused state
const style = document.createElement('style');
style.textContent = `
    .field-focused {
        position: relative;
    }
    
    .field-focused::before {
        content: '';
        position: absolute;
        top: -2px;
        left: -2px;
        right: -2px;
        bottom: -2px;
        border: 2px solid var(--accent-color);
        border-radius: var(--radius-sm);
        pointer-events: none;
        animation: pulse 1s ease infinite;
    }
    
    /* Smooth page transitions */
    .o_action_manager {
        animation: fadeIn 0.4s ease;
    }
    
    /* Loading overlay styles */
    .loading-overlay {
        transition: opacity 0.3s ease;
    }
    
    .loading-overlay .spinner {
        width: 50px;
        height: 50px;
        border: 4px solid rgba(255, 255, 255, 0.3);
        border-top-color: white;
    }
`;
document.head.appendChild(style);

console.log('✨ FITDNU HR AI v3.1 - UI Enhancements loaded');
